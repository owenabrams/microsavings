-- ============================================================================
-- MEETING SCHEDULER SYSTEM - SEED MEETING TEMPLATES
-- Migration: 004_seed_meeting_templates.sql
-- Description: Creates default meeting templates for all groups
-- Date: 2025-10-02
-- ============================================================================

BEGIN;

-- ============================================================================
-- CREATE DEFAULT MEETING TEMPLATES FOR ALL GROUPS
-- ============================================================================

-- Insert Weekly Regular Meeting Templates
INSERT INTO meeting_templates (
    group_id, template_name, template_description, meeting_type,
    default_duration_minutes, default_location, default_agenda,
    is_recurring, recurrence_pattern, recurrence_day_of_week,
    auto_invite_all_members, default_invitation_message,
    template_activities, created_by
)
SELECT 
    sg.id as group_id,
    'Weekly ' || sg.name || ' Meeting' as template_name,
    'Regular weekly meeting for ' || sg.name || ' savings group' as template_description,
    'REGULAR' as meeting_type,
    120 as default_duration_minutes,
    sg.name || ' Meeting Location' as default_location,
    '1. Opening Prayer
2. Attendance Check
3. Minutes Review from Previous Meeting
4. Individual Savings Collection
5. Loan Applications Review
6. Loan Disbursements
7. Loan Repayments
8. Fine Collection
9. Any Other Business (AOB)
10. Closing Prayer' as default_agenda,
    TRUE as is_recurring,
    'WEEKLY' as recurrence_pattern,
    3 as recurrence_day_of_week, -- Wednesday
    TRUE as auto_invite_all_members,
    'You are invited to the weekly ' || sg.name || ' meeting. Please confirm your attendance and come prepared with your savings contribution.' as default_invitation_message,
    '[
        {"order": 1, "name": "Opening Prayer", "type": "OPENING_PRAYER", "duration": 5, "mandatory": true},
        {"order": 2, "name": "Attendance Check", "type": "ATTENDANCE_CHECK", "duration": 10, "mandatory": true},
        {"order": 3, "name": "Minutes Review", "type": "MINUTES_REVIEW", "duration": 15, "mandatory": true},
        {"order": 4, "name": "Individual Savings Collection", "type": "INDIVIDUAL_SAVINGS", "duration": 30, "mandatory": true, "expected_amount": 5000},
        {"order": 5, "name": "Loan Applications Review", "type": "LOAN_APPLICATIONS", "duration": 20, "mandatory": false, "requires_voting": true},
        {"order": 6, "name": "Loan Disbursements", "type": "LOAN_DISBURSEMENTS", "duration": 15, "mandatory": false},
        {"order": 7, "name": "Loan Repayments", "type": "LOAN_REPAYMENTS", "duration": 15, "mandatory": false},
        {"order": 8, "name": "Fine Collection", "type": "FINE_COLLECTION", "duration": 10, "mandatory": false, "expected_amount": 1000},
        {"order": 9, "name": "Any Other Business", "type": "AOB", "duration": 10, "mandatory": false},
        {"order": 10, "name": "Closing Prayer", "type": "CLOSING_PRAYER", "duration": 5, "mandatory": true}
    ]'::jsonb as template_activities,
    1 as created_by
FROM savings_groups sg
WHERE NOT EXISTS (
    SELECT 1 FROM meeting_templates mt 
    WHERE mt.group_id = sg.id 
    AND mt.template_name = 'Weekly ' || sg.name || ' Meeting'
);

-- Insert Monthly Review Meeting Templates
INSERT INTO meeting_templates (
    group_id, template_name, template_description, meeting_type,
    default_duration_minutes, default_location, default_agenda,
    is_recurring, recurrence_pattern, recurrence_day_of_month,
    auto_invite_all_members, default_invitation_message,
    template_activities, created_by
)
SELECT 
    sg.id as group_id,
    'Monthly ' || sg.name || ' Review' as template_name,
    'Monthly review and planning meeting for ' || sg.name as template_description,
    'SPECIAL' as meeting_type,
    180 as default_duration_minutes,
    sg.name || ' Meeting Location' as default_location,
    '1. Opening Prayer and Attendance
2. Monthly Financial Review
3. Loan Portfolio Analysis
4. Member Performance Review
5. Group Performance Assessment
6. Planning for Next Month
7. Training Session (if scheduled)
8. Closing Prayer' as default_agenda,
    TRUE as is_recurring,
    'MONTHLY' as recurrence_pattern,
    1 as recurrence_day_of_month, -- First day of month
    TRUE as auto_invite_all_members,
    'Monthly review meeting for ' || sg.name || '. Important decisions will be made regarding group performance and future planning. Your attendance is crucial.' as default_invitation_message,
    '[
        {"order": 1, "name": "Opening & Attendance", "type": "ATTENDANCE_CHECK", "duration": 15, "mandatory": true},
        {"order": 2, "name": "Monthly Financial Review", "type": "GROUP_SAVINGS", "duration": 45, "mandatory": true, "requires_documentation": true},
        {"order": 3, "name": "Loan Portfolio Analysis", "type": "LOAN_APPLICATIONS", "duration": 60, "mandatory": true, "requires_documentation": true},
        {"order": 4, "name": "Member Performance Review", "type": "VOTING_SESSION", "duration": 30, "mandatory": true, "requires_voting": true},
        {"order": 5, "name": "Group Performance Assessment", "type": "AOB", "duration": 20, "mandatory": true},
        {"order": 6, "name": "Next Month Planning", "type": "AOB", "duration": 25, "mandatory": true},
        {"order": 7, "name": "Training Session", "type": "TRAINING_SESSION", "duration": 30, "mandatory": false},
        {"order": 8, "name": "Closing Prayer", "type": "CLOSING_PRAYER", "duration": 5, "mandatory": true}
    ]'::jsonb as template_activities,
    1 as created_by
FROM savings_groups sg
WHERE NOT EXISTS (
    SELECT 1 FROM meeting_templates mt 
    WHERE mt.group_id = sg.id 
    AND mt.template_name = 'Monthly ' || sg.name || ' Review'
);

-- Insert Annual General Meeting Templates
INSERT INTO meeting_templates (
    group_id, template_name, template_description, meeting_type,
    default_duration_minutes, default_location, default_agenda,
    is_recurring, recurrence_pattern,
    auto_invite_all_members, default_invitation_message,
    template_activities, created_by
)
SELECT 
    sg.id as group_id,
    'Annual ' || sg.name || ' General Meeting' as template_name,
    'Annual general meeting for ' || sg.name || ' with elections and major decisions' as template_description,
    'ANNUAL' as meeting_type,
    240 as default_duration_minutes,
    sg.name || ' Annual Meeting Venue' as default_location,
    '1. Opening Ceremony
2. Annual Report Presentation
3. Financial Report and Audit
4. Election of Leadership
5. Constitutional Amendments (if any)
6. Strategic Planning for Next Year
7. Share-out Ceremony (if applicable)
8. Closing Ceremony' as default_agenda,
    TRUE as is_recurring,
    'ANNUALLY' as recurrence_pattern,
    TRUE as auto_invite_all_members,
    'You are cordially invited to the Annual General Meeting of ' || sg.name || '. This is a mandatory meeting where important decisions about the group''s future will be made.' as default_invitation_message,
    '[
        {"order": 1, "name": "Opening Ceremony", "type": "OPENING_PRAYER", "duration": 20, "mandatory": true},
        {"order": 2, "name": "Annual Report Presentation", "type": "AOB", "duration": 45, "mandatory": true, "requires_documentation": true},
        {"order": 3, "name": "Financial Report and Audit", "type": "GROUP_SAVINGS", "duration": 60, "mandatory": true, "requires_documentation": true},
        {"order": 4, "name": "Election of Leadership", "type": "VOTING_SESSION", "duration": 45, "mandatory": true, "requires_voting": true},
        {"order": 5, "name": "Constitutional Amendments", "type": "VOTING_SESSION", "duration": 30, "mandatory": false, "requires_voting": true},
        {"order": 6, "name": "Strategic Planning", "type": "AOB", "duration": 45, "mandatory": true},
        {"order": 7, "name": "Share-out Ceremony", "type": "GROUP_SAVINGS", "duration": 30, "mandatory": false},
        {"order": 8, "name": "Closing Ceremony", "type": "CLOSING_PRAYER", "duration": 15, "mandatory": true}
    ]'::jsonb as template_activities,
    1 as created_by
FROM savings_groups sg
WHERE NOT EXISTS (
    SELECT 1 FROM meeting_templates mt 
    WHERE mt.group_id = sg.id 
    AND mt.template_name = 'Annual ' || sg.name || ' General Meeting'
);

-- Insert Emergency Meeting Templates
INSERT INTO meeting_templates (
    group_id, template_name, template_description, meeting_type,
    default_duration_minutes, default_location, default_agenda,
    is_recurring, auto_invite_all_members, default_invitation_message,
    template_activities, created_by
)
SELECT 
    sg.id as group_id,
    'Emergency ' || sg.name || ' Meeting' as template_name,
    'Emergency meeting template for urgent matters requiring immediate attention' as template_description,
    'EMERGENCY' as meeting_type,
    90 as default_duration_minutes,
    sg.name || ' Emergency Meeting Location' as default_location,
    '1. Opening Prayer
2. Attendance Check
3. Presentation of Emergency Issue
4. Discussion and Deliberation
5. Voting on Proposed Solutions
6. Action Plan Development
7. Closing Prayer' as default_agenda,
    FALSE as is_recurring,
    TRUE as auto_invite_all_members,
    'URGENT: Emergency meeting for ' || sg.name || '. Your immediate attendance is required to address critical group matters.' as default_invitation_message,
    '[
        {"order": 1, "name": "Opening Prayer", "type": "OPENING_PRAYER", "duration": 5, "mandatory": true},
        {"order": 2, "name": "Attendance Check", "type": "ATTENDANCE_CHECK", "duration": 5, "mandatory": true},
        {"order": 3, "name": "Emergency Issue Presentation", "type": "AOB", "duration": 20, "mandatory": true},
        {"order": 4, "name": "Discussion and Deliberation", "type": "AOB", "duration": 30, "mandatory": true},
        {"order": 5, "name": "Voting on Solutions", "type": "VOTING_SESSION", "duration": 20, "mandatory": true, "requires_voting": true},
        {"order": 6, "name": "Action Plan Development", "type": "AOB", "duration": 15, "mandatory": true},
        {"order": 7, "name": "Closing Prayer", "type": "CLOSING_PRAYER", "duration": 5, "mandatory": true}
    ]'::jsonb as template_activities,
    1 as created_by
FROM savings_groups sg
WHERE NOT EXISTS (
    SELECT 1 FROM meeting_templates mt 
    WHERE mt.group_id = sg.id 
    AND mt.template_name = 'Emergency ' || sg.name || ' Meeting'
);

-- Insert Training Meeting Templates
INSERT INTO meeting_templates (
    group_id, template_name, template_description, meeting_type,
    default_duration_minutes, default_location, default_agenda,
    is_recurring, auto_invite_all_members, default_invitation_message,
    template_activities, created_by
)
SELECT 
    sg.id as group_id,
    'Financial Literacy Training - ' || sg.name as template_name,
    'Financial literacy and business skills training session' as template_description,
    'TRAINING' as meeting_type,
    150 as default_duration_minutes,
    sg.name || ' Training Venue' as default_location,
    '1. Opening and Introductions
2. Training Session Part 1
3. Break
4. Training Session Part 2
5. Practical Exercises
6. Q&A Session
7. Evaluation and Feedback
8. Closing' as default_agenda,
    FALSE as is_recurring,
    TRUE as auto_invite_all_members,
    'You are invited to a financial literacy training session for ' || sg.name || '. This training will help improve your financial management skills.' as default_invitation_message,
    '[
        {"order": 1, "name": "Opening and Introductions", "type": "OPENING_PRAYER", "duration": 15, "mandatory": true},
        {"order": 2, "name": "Training Session Part 1", "type": "TRAINING_SESSION", "duration": 45, "mandatory": true},
        {"order": 3, "name": "Break", "type": "AOB", "duration": 15, "mandatory": false},
        {"order": 4, "name": "Training Session Part 2", "type": "TRAINING_SESSION", "duration": 45, "mandatory": true},
        {"order": 5, "name": "Practical Exercises", "type": "TRAINING_SESSION", "duration": 30, "mandatory": true},
        {"order": 6, "name": "Q&A Session", "type": "AOB", "duration": 15, "mandatory": true},
        {"order": 7, "name": "Evaluation and Feedback", "type": "AOB", "duration": 10, "mandatory": true},
        {"order": 8, "name": "Closing", "type": "CLOSING_PRAYER", "duration": 5, "mandatory": true}
    ]'::jsonb as template_activities,
    1 as created_by
FROM savings_groups sg
WHERE NOT EXISTS (
    SELECT 1 FROM meeting_templates mt 
    WHERE mt.group_id = sg.id 
    AND mt.template_name = 'Financial Literacy Training - ' || sg.name
);

-- ============================================================================
-- UPDATE STATISTICS
-- ============================================================================

-- Update table statistics for better query planning
ANALYZE meeting_templates;
ANALYZE meeting_invitations;
ANALYZE planned_meeting_activities;
ANALYZE meeting_activity_participants;
ANALYZE scheduler_calendar;

COMMIT;
