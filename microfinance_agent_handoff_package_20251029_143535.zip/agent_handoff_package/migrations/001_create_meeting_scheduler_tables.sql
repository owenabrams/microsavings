-- ============================================================================
-- MEETING SCHEDULER SYSTEM - DATABASE MIGRATION
-- Migration: 001_create_meeting_scheduler_tables.sql
-- Description: Creates all tables for MS Teams-like meeting scheduler system
-- Date: 2025-10-02
-- ============================================================================

BEGIN;

-- ============================================================================
-- 1. MEETING INVITATIONS TABLE
-- ============================================================================
CREATE TABLE IF NOT EXISTS meeting_invitations (
    id SERIAL PRIMARY KEY,
    meeting_id INTEGER NOT NULL REFERENCES meetings(id) ON DELETE CASCADE,
    member_id INTEGER NOT NULL REFERENCES group_members(id) ON DELETE CASCADE,
    
    -- Invitation details
    invitation_status VARCHAR(20) DEFAULT 'PENDING' NOT NULL,
    invited_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP NOT NULL,
    response_date TIMESTAMP,
    response_notes TEXT,
    
    -- Meeting role for this member
    meeting_role VARCHAR(50) DEFAULT 'PARTICIPANT' NOT NULL,
    is_required BOOLEAN DEFAULT TRUE NOT NULL,
    can_delegate BOOLEAN DEFAULT FALSE NOT NULL,
    
    -- Notification preferences
    email_notification_sent BOOLEAN DEFAULT FALSE NOT NULL,
    sms_notification_sent BOOLEAN DEFAULT FALSE NOT NULL,
    reminder_sent BOOLEAN DEFAULT FALSE NOT NULL,
    
    -- Audit fields
    invited_by INTEGER NOT NULL REFERENCES users(id),
    created_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP NOT NULL,
    
    -- Constraints
    CONSTRAINT check_invitation_status CHECK (invitation_status IN ('PENDING', 'ACCEPTED', 'DECLINED', 'TENTATIVE', 'NO_RESPONSE')),
    CONSTRAINT check_meeting_role CHECK (meeting_role IN ('CHAIRPERSON', 'SECRETARY', 'TREASURER', 'PARTICIPANT', 'OBSERVER')),
    UNIQUE(meeting_id, member_id)
);

-- ============================================================================
-- 2. PLANNED MEETING ACTIVITIES TABLE
-- ============================================================================
CREATE TABLE IF NOT EXISTS planned_meeting_activities (
    id SERIAL PRIMARY KEY,
    meeting_id INTEGER NOT NULL REFERENCES meetings(id) ON DELETE CASCADE,
    
    -- Activity planning
    activity_order INTEGER NOT NULL,
    activity_name VARCHAR(255) NOT NULL,
    activity_type VARCHAR(50) NOT NULL,
    estimated_duration_minutes INTEGER DEFAULT 15 NOT NULL,
    is_mandatory BOOLEAN DEFAULT TRUE NOT NULL,
    
    -- Activity configuration
    activity_config JSONB,
    expected_participants INTEGER,
    requires_voting BOOLEAN DEFAULT FALSE NOT NULL,
    requires_documentation BOOLEAN DEFAULT FALSE NOT NULL,
    
    -- Financial planning
    estimated_amount DECIMAL(15,2) DEFAULT 0.00 NOT NULL,
    fund_type VARCHAR(50),
    
    -- Activity status
    status VARCHAR(20) DEFAULT 'PLANNED' NOT NULL,
    actual_duration_minutes INTEGER,
    actual_participants INTEGER,
    actual_amount DECIMAL(15,2) DEFAULT 0.00 NOT NULL,
    
    -- Execution details
    started_at TIMESTAMP,
    completed_at TIMESTAMP,
    outcome_notes TEXT,
    
    -- Audit fields
    planned_by INTEGER NOT NULL REFERENCES users(id),
    created_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP NOT NULL,
    
    -- Constraints
    CONSTRAINT check_activity_type CHECK (activity_type IN (
        'OPENING_PRAYER', 'ATTENDANCE_CHECK', 'MINUTES_REVIEW', 
        'INDIVIDUAL_SAVINGS', 'GROUP_SAVINGS', 'LOAN_APPLICATIONS', 
        'LOAN_DISBURSEMENTS', 'LOAN_REPAYMENTS', 'FINE_COLLECTION', 
        'VOTING_SESSION', 'TRAINING_SESSION', 'AOB', 'CLOSING_PRAYER'
    )),
    CONSTRAINT check_activity_status CHECK (status IN ('PLANNED', 'IN_PROGRESS', 'COMPLETED', 'CANCELLED', 'POSTPONED')),
    CONSTRAINT check_estimated_amount CHECK (estimated_amount >= 0),
    CONSTRAINT check_actual_amount CHECK (actual_amount >= 0),
    UNIQUE(meeting_id, activity_order)
);

-- ============================================================================
-- 3. MEETING TEMPLATES TABLE
-- ============================================================================
CREATE TABLE IF NOT EXISTS meeting_templates (
    id SERIAL PRIMARY KEY,
    group_id INTEGER NOT NULL REFERENCES savings_groups(id) ON DELETE CASCADE,
    
    -- Template details
    template_name VARCHAR(255) NOT NULL,
    template_description TEXT,
    meeting_type VARCHAR(20) DEFAULT 'REGULAR' NOT NULL,
    
    -- Default settings
    default_duration_minutes INTEGER DEFAULT 120 NOT NULL,
    default_location VARCHAR(255),
    default_agenda TEXT,
    
    -- Recurrence settings
    is_recurring BOOLEAN DEFAULT FALSE NOT NULL,
    recurrence_pattern VARCHAR(50),
    recurrence_day_of_week INTEGER,
    recurrence_day_of_month INTEGER,
    
    -- Auto-invitation settings
    auto_invite_all_members BOOLEAN DEFAULT TRUE NOT NULL,
    default_invitation_message TEXT,
    
    -- Template activities (JSON array of activity configurations)
    template_activities JSONB,
    
    -- Template status
    is_active BOOLEAN DEFAULT TRUE NOT NULL,
    
    -- Audit fields
    created_by INTEGER NOT NULL REFERENCES users(id),
    created_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP NOT NULL,
    
    -- Constraints
    CONSTRAINT check_meeting_type CHECK (meeting_type IN ('REGULAR', 'SPECIAL', 'ANNUAL', 'EMERGENCY', 'TRAINING')),
    CONSTRAINT check_recurrence_pattern CHECK (recurrence_pattern IN ('WEEKLY', 'MONTHLY', 'QUARTERLY', 'ANNUALLY') OR recurrence_pattern IS NULL),
    CONSTRAINT check_recurrence_day_of_week CHECK (recurrence_day_of_week BETWEEN 1 AND 7 OR recurrence_day_of_week IS NULL),
    CONSTRAINT check_recurrence_day_of_month CHECK (recurrence_day_of_month BETWEEN 1 AND 31 OR recurrence_day_of_month IS NULL),
    CONSTRAINT check_default_duration CHECK (default_duration_minutes > 0)
);

-- ============================================================================
-- 4. MEETING ACTIVITY PARTICIPANTS TABLE
-- ============================================================================
CREATE TABLE IF NOT EXISTS meeting_activity_participants (
    id SERIAL PRIMARY KEY,
    planned_activity_id INTEGER NOT NULL REFERENCES planned_meeting_activities(id) ON DELETE CASCADE,
    member_id INTEGER NOT NULL REFERENCES group_members(id) ON DELETE CASCADE,
    
    -- Participation planning
    participation_type VARCHAR(50) DEFAULT 'PARTICIPANT' NOT NULL,
    is_required BOOLEAN DEFAULT FALSE NOT NULL,
    estimated_contribution DECIMAL(12,2) DEFAULT 0.00 NOT NULL,
    
    -- Actual participation
    actually_participated BOOLEAN DEFAULT FALSE NOT NULL,
    actual_contribution DECIMAL(12,2) DEFAULT 0.00 NOT NULL,
    participation_notes TEXT,
    participation_score DECIMAL(3,1) DEFAULT 0.0 NOT NULL,
    
    -- Audit fields
    planned_by INTEGER NOT NULL REFERENCES users(id),
    recorded_by INTEGER REFERENCES users(id),
    created_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP NOT NULL,
    
    -- Constraints
    CONSTRAINT check_participation_type CHECK (participation_type IN ('LEADER', 'PARTICIPANT', 'OBSERVER', 'FACILITATOR')),
    CONSTRAINT check_participation_score CHECK (participation_score >= 0 AND participation_score <= 10),
    CONSTRAINT check_estimated_contribution CHECK (estimated_contribution >= 0),
    CONSTRAINT check_actual_contribution CHECK (actual_contribution >= 0),
    UNIQUE(planned_activity_id, member_id)
);

-- ============================================================================
-- 5. SCHEDULER CALENDAR TABLE
-- ============================================================================
CREATE TABLE IF NOT EXISTS scheduler_calendar (
    id SERIAL PRIMARY KEY,
    
    -- Calendar entry details
    calendar_date DATE NOT NULL,
    time_slot TIME NOT NULL,
    duration_minutes INTEGER DEFAULT 120 NOT NULL,
    
    -- Meeting reference
    meeting_id INTEGER REFERENCES meetings(id) ON DELETE SET NULL,
    group_id INTEGER NOT NULL REFERENCES savings_groups(id) ON DELETE CASCADE,
    
    -- Scheduling details
    title VARCHAR(255) NOT NULL,
    description TEXT,
    location VARCHAR(255),
    meeting_type VARCHAR(20) DEFAULT 'REGULAR' NOT NULL,
    
    -- Availability and booking
    is_booked BOOLEAN DEFAULT FALSE NOT NULL,
    is_available BOOLEAN DEFAULT TRUE NOT NULL,
    booking_status VARCHAR(20) DEFAULT 'AVAILABLE' NOT NULL,
    
    -- Conflict management
    has_conflicts BOOLEAN DEFAULT FALSE NOT NULL,
    conflict_notes TEXT,
    
    -- Recurring meeting info
    is_recurring BOOLEAN DEFAULT FALSE NOT NULL,
    recurrence_id INTEGER,
    template_id INTEGER REFERENCES meeting_templates(id),
    
    -- Notification settings
    reminder_minutes INTEGER DEFAULT 30 NOT NULL,
    send_invitations BOOLEAN DEFAULT TRUE NOT NULL,
    
    -- Audit fields
    scheduled_by INTEGER NOT NULL REFERENCES users(id),
    created_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP NOT NULL,
    
    -- Constraints
    CONSTRAINT check_booking_status CHECK (booking_status IN ('AVAILABLE', 'BOOKED', 'TENTATIVE', 'CANCELLED', 'COMPLETED')),
    CONSTRAINT check_meeting_type_scheduler CHECK (meeting_type IN ('REGULAR', 'SPECIAL', 'ANNUAL', 'EMERGENCY', 'TRAINING')),
    CONSTRAINT check_duration CHECK (duration_minutes > 0),
    CONSTRAINT check_reminder_minutes CHECK (reminder_minutes >= 0)
);

COMMIT;
