-- ============================================================================
-- PHASE 1 & IGA IMPROVEMENTS - DATABASE MIGRATION
-- Migration: 005_add_phase1_and_iga_tables.sql
-- Description: Adds tables for Phase 1 Financial Dashboard and IGA features
-- Date: 2025-10-22
-- ============================================================================

BEGIN;

-- ============================================================================
-- 1. RENAME groups TABLE TO savings_groups (if needed)
-- ============================================================================
-- Check if 'groups' table exists and rename to 'savings_groups'
DO $$
BEGIN
    IF EXISTS (SELECT 1 FROM information_schema.tables WHERE table_name = 'groups') THEN
        ALTER TABLE groups RENAME TO savings_groups;
        -- Update foreign keys
        ALTER TABLE members DROP CONSTRAINT IF EXISTS members_group_id_fkey;
        ALTER TABLE members ADD CONSTRAINT members_group_id_fkey 
            FOREIGN KEY (group_id) REFERENCES savings_groups(id) ON DELETE CASCADE;
        
        ALTER TABLE meetings DROP CONSTRAINT IF EXISTS meetings_group_id_fkey;
        ALTER TABLE meetings ADD CONSTRAINT meetings_group_id_fkey 
            FOREIGN KEY (group_id) REFERENCES savings_groups(id) ON DELETE CASCADE;
        
        ALTER TABLE meeting_activities DROP CONSTRAINT IF EXISTS meeting_activities_group_id_fkey;
        ALTER TABLE meeting_activities ADD CONSTRAINT meeting_activities_group_id_fkey 
            FOREIGN KEY (group_id) REFERENCES savings_groups(id) ON DELETE CASCADE;
    END IF;
END $$;

-- ============================================================================
-- 2. ADD MISSING COLUMNS TO EXISTING TABLES
-- ============================================================================

-- Add columns to savings_groups if they don't exist
ALTER TABLE savings_groups ADD COLUMN IF NOT EXISTS region VARCHAR(100);
ALTER TABLE savings_groups ADD COLUMN IF NOT EXISTS parish VARCHAR(100);
ALTER TABLE savings_groups ADD COLUMN IF NOT EXISTS village VARCHAR(100);
ALTER TABLE savings_groups ADD COLUMN IF NOT EXISTS district VARCHAR(100);
ALTER TABLE savings_groups ADD COLUMN IF NOT EXISTS meeting_day VARCHAR(20);
ALTER TABLE savings_groups ADD COLUMN IF NOT EXISTS meeting_time TIME;
ALTER TABLE savings_groups ADD COLUMN IF NOT EXISTS status VARCHAR(20) DEFAULT 'active';
ALTER TABLE savings_groups ADD COLUMN IF NOT EXISTS members_count INTEGER DEFAULT 0;
ALTER TABLE savings_groups ADD COLUMN IF NOT EXISTS savings_balance DECIMAL(12,2) DEFAULT 0.00;
ALTER TABLE savings_groups ADD COLUMN IF NOT EXISTS loan_fund_balance DECIMAL(12,2) DEFAULT 0.00;
ALTER TABLE savings_groups ADD COLUMN IF NOT EXISTS created_by INTEGER REFERENCES users(id);
ALTER TABLE savings_groups ADD COLUMN IF NOT EXISTS chair_member_id INTEGER;
ALTER TABLE savings_groups ADD COLUMN IF NOT EXISTS treasurer_member_id INTEGER;
ALTER TABLE savings_groups ADD COLUMN IF NOT EXISTS secretary_member_id INTEGER;

-- Rename members table to group_members (if members exists and group_members doesn't)
DO $$
BEGIN
    IF EXISTS (SELECT 1 FROM information_schema.tables WHERE table_name = 'members')
       AND NOT EXISTS (SELECT 1 FROM information_schema.tables WHERE table_name = 'group_members') THEN
        ALTER TABLE members RENAME TO group_members;
    END IF;
END $$;

-- Add columns to group_members if they don't exist
ALTER TABLE group_members ADD COLUMN IF NOT EXISTS role VARCHAR(50) DEFAULT 'member';
ALTER TABLE group_members ADD COLUMN IF NOT EXISTS status VARCHAR(20) DEFAULT 'active';
ALTER TABLE group_members ADD COLUMN IF NOT EXISTS date_joined DATE DEFAULT CURRENT_DATE;
ALTER TABLE group_members ADD COLUMN IF NOT EXISTS user_id INTEGER REFERENCES users(id);
ALTER TABLE group_members ADD COLUMN IF NOT EXISTS gender VARCHAR(20);
ALTER TABLE group_members ADD COLUMN IF NOT EXISTS is_active BOOLEAN DEFAULT TRUE;
ALTER TABLE group_members ADD COLUMN IF NOT EXISTS attendance_percentage DECIMAL(5,2) DEFAULT 0.00;
ALTER TABLE group_members ADD COLUMN IF NOT EXISTS is_eligible_for_loans BOOLEAN DEFAULT FALSE;
ALTER TABLE group_members ADD COLUMN IF NOT EXISTS share_balance DECIMAL(12,2) DEFAULT 0.00;
ALTER TABLE group_members ADD COLUMN IF NOT EXISTS total_contributions DECIMAL(12,2) DEFAULT 0.00;
ALTER TABLE group_members ADD COLUMN IF NOT EXISTS chair_member_id INTEGER;
ALTER TABLE group_members ADD COLUMN IF NOT EXISTS treasurer_member_id INTEGER;
ALTER TABLE group_members ADD COLUMN IF NOT EXISTS secretary_member_id INTEGER;

-- Add columns to meetings if they don't exist
ALTER TABLE meetings ADD COLUMN IF NOT EXISTS chairperson_id INTEGER;
ALTER TABLE meetings ADD COLUMN IF NOT EXISTS secretary_id INTEGER;
ALTER TABLE meetings ADD COLUMN IF NOT EXISTS treasurer_id INTEGER;
ALTER TABLE meetings ADD COLUMN IF NOT EXISTS meeting_date DATE;
ALTER TABLE meetings ADD COLUMN IF NOT EXISTS meeting_time TIME;

-- ============================================================================
-- 3. IGA (INCOME GENERATING ACTIVITIES) TABLES
-- ============================================================================

-- IGA Activities Table
CREATE TABLE IF NOT EXISTS savings_group_iga (
    id SERIAL PRIMARY KEY,
    group_id INTEGER NOT NULL REFERENCES savings_groups(id) ON DELETE CASCADE,
    
    -- IGA Details
    name VARCHAR(255) NOT NULL,
    description TEXT,
    activity_type VARCHAR(100),
    
    -- Financial Details
    initial_capital DECIMAL(12,2) NOT NULL,
    current_balance DECIMAL(12,2) DEFAULT 0.00,
    total_profit DECIMAL(12,2) DEFAULT 0.00,
    total_loss DECIMAL(12,2) DEFAULT 0.00,
    
    -- Status
    status VARCHAR(20) DEFAULT 'active',
    start_date DATE NOT NULL,
    end_date DATE,
    
    -- Audit
    created_by INTEGER REFERENCES users(id),
    created_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    
    CONSTRAINT check_iga_status CHECK (status IN ('active', 'inactive', 'completed', 'suspended'))
);

-- IGA Member Participation Table
CREATE TABLE IF NOT EXISTS iga_member_participation (
    id SERIAL PRIMARY KEY,
    iga_id INTEGER NOT NULL REFERENCES savings_group_iga(id) ON DELETE CASCADE,
    member_id INTEGER NOT NULL REFERENCES group_members(id) ON DELETE CASCADE,

    -- Participation Details
    contribution_amount DECIMAL(12,2) NOT NULL,
    participation_percentage DECIMAL(5,2),
    role VARCHAR(50),

    -- Status
    status VARCHAR(20) DEFAULT 'active',
    joined_date DATE DEFAULT CURRENT_DATE,

    -- Audit
    created_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,

    UNIQUE(iga_id, member_id),
    CONSTRAINT check_participation_status CHECK (status IN ('active', 'inactive', 'withdrawn'))
);

-- IGA Cashflow Table
CREATE TABLE IF NOT EXISTS iga_cashflow (
    id SERIAL PRIMARY KEY,
    iga_id INTEGER NOT NULL REFERENCES savings_group_iga(id) ON DELETE CASCADE,
    
    -- Transaction Details
    transaction_type VARCHAR(50) NOT NULL,
    amount DECIMAL(12,2) NOT NULL,
    description TEXT,
    
    -- Financial Impact
    profit_loss DECIMAL(12,2),
    balance_after DECIMAL(12,2),
    
    -- Status
    status VARCHAR(20) DEFAULT 'completed',
    transaction_date DATE DEFAULT CURRENT_DATE,
    
    -- Audit
    recorded_by INTEGER REFERENCES users(id),
    created_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    
    CONSTRAINT check_transaction_type CHECK (transaction_type IN ('income', 'expense', 'profit_distribution', 'loss_recovery', 'capital_return'))
);

-- IGA Member Returns Table
CREATE TABLE IF NOT EXISTS iga_member_returns (
    id SERIAL PRIMARY KEY,
    iga_id INTEGER NOT NULL REFERENCES savings_group_iga(id) ON DELETE CASCADE,
    member_id INTEGER NOT NULL REFERENCES group_members(id) ON DELETE CASCADE,

    -- Return Details
    return_amount DECIMAL(12,2) NOT NULL,
    return_percentage DECIMAL(5,2),
    return_type VARCHAR(50),

    -- Status
    status VARCHAR(20) DEFAULT 'pending',
    return_date DATE,

    -- Audit
    created_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,

    UNIQUE(iga_id, member_id),
    CONSTRAINT check_return_status CHECK (status IN ('pending', 'approved', 'paid', 'cancelled'))
);

-- ============================================================================
-- 4. CREATE INDEXES FOR PERFORMANCE
-- ============================================================================

CREATE INDEX IF NOT EXISTS idx_iga_group_id ON savings_group_iga(group_id);
CREATE INDEX IF NOT EXISTS idx_iga_participation_iga_id ON iga_member_participation(iga_id);
CREATE INDEX IF NOT EXISTS idx_iga_participation_member_id ON iga_member_participation(member_id);
CREATE INDEX IF NOT EXISTS idx_iga_cashflow_iga_id ON iga_cashflow(iga_id);
CREATE INDEX IF NOT EXISTS idx_iga_cashflow_date ON iga_cashflow(transaction_date);
CREATE INDEX IF NOT EXISTS idx_iga_returns_iga_id ON iga_member_returns(iga_id);
CREATE INDEX IF NOT EXISTS idx_iga_returns_member_id ON iga_member_returns(member_id);

COMMIT;

