-- ============================================================================
-- ACTIVITY DOCUMENTS TABLE MIGRATION
-- Migration: 006_add_activity_documents_table.sql
-- Description: Enhances existing activity_documents table with additional fields
-- Date: 2025-10-25
-- ============================================================================

BEGIN;

-- ============================================================================
-- 1. ADD MISSING COLUMNS TO EXISTING ACTIVITY_DOCUMENTS TABLE
-- ============================================================================
-- The table already exists, so we add missing columns
ALTER TABLE activity_documents
ADD COLUMN IF NOT EXISTS meeting_activity_id INTEGER REFERENCES meeting_activities(id) ON DELETE CASCADE,
ADD COLUMN IF NOT EXISTS member_participation_id INTEGER REFERENCES member_activity_participation(id) ON DELETE CASCADE,
ADD COLUMN IF NOT EXISTS meeting_id INTEGER REFERENCES meetings(id) ON DELETE CASCADE,
ADD COLUMN IF NOT EXISTS original_file_name VARCHAR(255),
ADD COLUMN IF NOT EXISTS file_type VARCHAR(50),
ADD COLUMN IF NOT EXISTS mime_type VARCHAR(100),
ADD COLUMN IF NOT EXISTS title VARCHAR(200),
ADD COLUMN IF NOT EXISTS description TEXT,
ADD COLUMN IF NOT EXISTS is_verified BOOLEAN DEFAULT FALSE NOT NULL,
ADD COLUMN IF NOT EXISTS verified_by INTEGER REFERENCES users(id) ON DELETE SET NULL,
ADD COLUMN IF NOT EXISTS verified_date TIMESTAMP,
ADD COLUMN IF NOT EXISTS verification_notes TEXT,
ADD COLUMN IF NOT EXISTS is_public BOOLEAN DEFAULT FALSE NOT NULL,
ADD COLUMN IF NOT EXISTS access_level VARCHAR(20) DEFAULT 'GROUP' NOT NULL;

-- Update existing records to use activity_id as meeting_activity_id
UPDATE activity_documents
SET meeting_activity_id = activity_id
WHERE meeting_activity_id IS NULL AND activity_id IS NOT NULL;

-- Populate meeting_id from meeting_activities
UPDATE activity_documents ad
SET meeting_id = ma.meeting_id
FROM meeting_activities ma
WHERE ad.meeting_activity_id = ma.id AND ad.meeting_id IS NULL;

-- ============================================================================
-- 2. CREATE INDEXES FOR PERFORMANCE
-- ============================================================================
CREATE INDEX IF NOT EXISTS idx_activity_documents_meeting_activity_id
    ON activity_documents(meeting_activity_id);

CREATE INDEX IF NOT EXISTS idx_activity_documents_member_participation_id
    ON activity_documents(member_participation_id);

CREATE INDEX IF NOT EXISTS idx_activity_documents_meeting_id
    ON activity_documents(meeting_id);

CREATE INDEX IF NOT EXISTS idx_activity_documents_uploaded_by
    ON activity_documents(uploaded_by);

CREATE INDEX IF NOT EXISTS idx_activity_documents_document_type
    ON activity_documents(document_type);

CREATE INDEX IF NOT EXISTS idx_activity_documents_is_verified
    ON activity_documents(is_verified);

CREATE INDEX IF NOT EXISTS idx_activity_documents_created_date
    ON activity_documents(created_date DESC);

-- ============================================================================
-- 3. UPDATE MEETING_ACTIVITIES TABLE TO TRACK ATTACHMENTS
-- ============================================================================
ALTER TABLE meeting_activities
ADD COLUMN IF NOT EXISTS has_attachments BOOLEAN DEFAULT FALSE NOT NULL,
ADD COLUMN IF NOT EXISTS attachment_count INTEGER DEFAULT 0 NOT NULL;

-- ============================================================================
-- 4. CREATE AUDIT LOG TABLE FOR DOCUMENT OPERATIONS
-- ============================================================================
CREATE TABLE IF NOT EXISTS activity_document_audit_log (
    id SERIAL PRIMARY KEY,
    document_id INTEGER NOT NULL REFERENCES activity_documents(id) ON DELETE CASCADE,
    action VARCHAR(50) NOT NULL,
    action_by INTEGER NOT NULL REFERENCES users(id) ON DELETE RESTRICT,
    action_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP NOT NULL,
    details JSONB,

    CONSTRAINT check_valid_action CHECK (action IN (
        'UPLOADED', 'VERIFIED', 'REJECTED', 'DOWNLOADED', 'DELETED', 'SHARED'
    ))
);

CREATE INDEX IF NOT EXISTS idx_document_audit_log_document_id
    ON activity_document_audit_log(document_id);

CREATE INDEX IF NOT EXISTS idx_document_audit_log_action_date
    ON activity_document_audit_log(action_date DESC);

COMMIT;

