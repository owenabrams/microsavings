-- ============================================================================
-- ALIGN ALL TABLES WITH ORM MODELS
-- ============================================================================
-- This migration adds ALL missing columns to match ORM model expectations
-- Date: 2025-10-28
-- ============================================================================

BEGIN;

-- ============================================================================
-- 1. saving_types - Add missing columns
-- ============================================================================
ALTER TABLE saving_types ADD COLUMN IF NOT EXISTS is_active BOOLEAN DEFAULT TRUE;
ALTER TABLE saving_types ADD COLUMN IF NOT EXISTS requires_target BOOLEAN DEFAULT FALSE;
ALTER TABLE saving_types ADD COLUMN IF NOT EXISTS allows_withdrawal BOOLEAN DEFAULT TRUE;
ALTER TABLE saving_types ADD COLUMN IF NOT EXISTS minimum_amount NUMERIC(10,2);
ALTER TABLE saving_types ADD COLUMN IF NOT EXISTS maximum_amount NUMERIC(10,2);
ALTER TABLE saving_types ADD COLUMN IF NOT EXISTS created_by INTEGER REFERENCES users(id);
ALTER TABLE saving_types ADD COLUMN IF NOT EXISTS created_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP;
ALTER TABLE saving_types ADD COLUMN IF NOT EXISTS updated_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP;

-- ============================================================================
-- 2. meetings - Add missing columns
-- ============================================================================
ALTER TABLE meetings ADD COLUMN IF NOT EXISTS agenda TEXT;
ALTER TABLE meetings ADD COLUMN IF NOT EXISTS minutes TEXT;
ALTER TABLE meetings ADD COLUMN IF NOT EXISTS attendance_count INTEGER DEFAULT 0;
ALTER TABLE meetings ADD COLUMN IF NOT EXISTS total_fines_collected NUMERIC(12,2) DEFAULT 0.00;
ALTER TABLE meetings ADD COLUMN IF NOT EXISTS total_loan_repayments NUMERIC(12,2) DEFAULT 0.00;
ALTER TABLE meetings ADD COLUMN IF NOT EXISTS chairperson_id INTEGER REFERENCES group_members(id);
ALTER TABLE meetings ADD COLUMN IF NOT EXISTS secretary_id INTEGER REFERENCES group_members(id);
ALTER TABLE meetings ADD COLUMN IF NOT EXISTS treasurer_id INTEGER REFERENCES group_members(id);
ALTER TABLE meetings ADD COLUMN IF NOT EXISTS created_by INTEGER REFERENCES users(id);
ALTER TABLE meetings ADD COLUMN IF NOT EXISTS recorded_by INTEGER REFERENCES users(id);
ALTER TABLE meetings ADD COLUMN IF NOT EXISTS scheduled_by INTEGER REFERENCES users(id);

-- ============================================================================
-- 3. group_loans - Add missing columns
-- ============================================================================
ALTER TABLE group_loans ADD COLUMN IF NOT EXISTS loan_type VARCHAR(50) DEFAULT 'REGULAR';
ALTER TABLE group_loans ADD COLUMN IF NOT EXISTS interest_rate NUMERIC(5,2) DEFAULT 0.00;
ALTER TABLE group_loans ADD COLUMN IF NOT EXISTS repayment_frequency VARCHAR(50) DEFAULT 'MONTHLY';
ALTER TABLE group_loans ADD COLUMN IF NOT EXISTS repayment_status VARCHAR(50) DEFAULT 'ACTIVE';
ALTER TABLE group_loans ADD COLUMN IF NOT EXISTS total_repaid NUMERIC(12,2) DEFAULT 0.00;
ALTER TABLE group_loans ADD COLUMN IF NOT EXISTS outstanding_balance NUMERIC(12,2);
ALTER TABLE group_loans ADD COLUMN IF NOT EXISTS approved_by INTEGER REFERENCES users(id);
ALTER TABLE group_loans ADD COLUMN IF NOT EXISTS approved_date TIMESTAMP;

-- ============================================================================
-- 4. member_savings - Add missing columns
-- ============================================================================
ALTER TABLE member_savings ADD COLUMN IF NOT EXISTS target_amount NUMERIC(12,2);
ALTER TABLE member_savings ADD COLUMN IF NOT EXISTS target_date DATE;
ALTER TABLE member_savings ADD COLUMN IF NOT EXISTS target_description TEXT;
ALTER TABLE member_savings ADD COLUMN IF NOT EXISTS is_target_achieved BOOLEAN DEFAULT FALSE;
ALTER TABLE member_savings ADD COLUMN IF NOT EXISTS target_achieved_date DATE;

-- ============================================================================
-- 5. saving_transactions - Add missing columns
-- ============================================================================
ALTER TABLE saving_transactions ADD COLUMN IF NOT EXISTS balance_after NUMERIC(12,2);
ALTER TABLE saving_transactions ADD COLUMN IF NOT EXISTS mobile_money_provider VARCHAR(50);
ALTER TABLE saving_transactions ADD COLUMN IF NOT EXISTS mobile_money_phone VARCHAR(20);
ALTER TABLE saving_transactions ADD COLUMN IF NOT EXISTS status VARCHAR(50) DEFAULT 'VERIFIED';
ALTER TABLE saving_transactions ADD COLUMN IF NOT EXISTS processed_date TIMESTAMP;

-- ============================================================================
-- 6. meeting_attendance - Add missing columns
-- ============================================================================
ALTER TABLE meeting_attendance ADD COLUMN IF NOT EXISTS attendance_time TIMESTAMP;
ALTER TABLE meeting_attendance ADD COLUMN IF NOT EXISTS excuse_reason TEXT;
ALTER TABLE meeting_attendance ADD COLUMN IF NOT EXISTS contributed_to_meeting BOOLEAN DEFAULT FALSE;
ALTER TABLE meeting_attendance ADD COLUMN IF NOT EXISTS meeting_notes TEXT;
ALTER TABLE meeting_attendance ADD COLUMN IF NOT EXISTS recorded_by INTEGER REFERENCES users(id);
ALTER TABLE meeting_attendance ADD COLUMN IF NOT EXISTS recorded_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP;

-- ============================================================================
-- 7. member_fines - Add missing columns
-- ============================================================================
ALTER TABLE member_fines ADD COLUMN IF NOT EXISTS fine_type VARCHAR(50);
ALTER TABLE member_fines ADD COLUMN IF NOT EXISTS reason TEXT;
ALTER TABLE member_fines ADD COLUMN IF NOT EXISTS status VARCHAR(50) DEFAULT 'PENDING';
ALTER TABLE member_fines ADD COLUMN IF NOT EXISTS paid_date DATE;
ALTER TABLE member_fines ADD COLUMN IF NOT EXISTS created_by INTEGER REFERENCES users(id);
ALTER TABLE member_fines ADD COLUMN IF NOT EXISTS created_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP;

-- ============================================================================
-- 8. group_cashbook - Add missing columns
-- ============================================================================
ALTER TABLE group_cashbook ADD COLUMN IF NOT EXISTS reference_number VARCHAR(100);
ALTER TABLE group_cashbook ADD COLUMN IF NOT EXISTS entry_type VARCHAR(50);
ALTER TABLE group_cashbook ADD COLUMN IF NOT EXISTS status VARCHAR(50) DEFAULT 'ACTIVE';
ALTER TABLE group_cashbook ADD COLUMN IF NOT EXISTS approved_by INTEGER REFERENCES users(id);
ALTER TABLE group_cashbook ADD COLUMN IF NOT EXISTS approved_date TIMESTAMP;

COMMIT;

-- Verify all changes
SELECT 'Migration completed successfully' AS status;

