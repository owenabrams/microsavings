-- ============================================================================
-- COMPLETE SCHEMA ALIGNMENT MIGRATION
-- ============================================================================
-- This migration aligns ALL database tables with ORM model expectations
-- Based on comprehensive schema audit completed 2025-10-27
-- ============================================================================

BEGIN;

-- ============================================================================
-- TABLE 1: savings_groups
-- ============================================================================

-- Add missing column
ALTER TABLE savings_groups ADD COLUMN IF NOT EXISTS loan_balance NUMERIC(15,2) DEFAULT 0.00;

-- Update existing rows
UPDATE savings_groups SET loan_balance = 0.00 WHERE loan_balance IS NULL;

-- ============================================================================
-- TABLE 2: group_members
-- ============================================================================

-- Fix NULL values before making columns NOT NULL
UPDATE group_members SET user_id = 1 WHERE user_id IS NULL;
UPDATE group_members SET gender = 'M' WHERE gender IS NULL OR gender = '';

-- Make columns NOT NULL as ORM expects
ALTER TABLE group_members ALTER COLUMN user_id SET NOT NULL;
ALTER TABLE group_members ALTER COLUMN gender SET NOT NULL;

-- Remove wrong columns (officer IDs belong in savings_groups table only)
ALTER TABLE group_members DROP COLUMN IF EXISTS chair_member_id;
ALTER TABLE group_members DROP COLUMN IF EXISTS treasurer_member_id;
ALTER TABLE group_members DROP COLUMN IF EXISTS secretary_member_id;

-- Remove old migration columns (name and phone are duplicates)
-- First verify data is in first_name/last_name and phone_number
DO $$
BEGIN
    -- Check if any rows have name but not first_name/last_name
    IF EXISTS (
        SELECT 1 FROM group_members 
        WHERE (first_name IS NULL OR last_name IS NULL) 
        AND name IS NOT NULL
    ) THEN
        -- Migrate any remaining data
        UPDATE group_members 
        SET first_name = SPLIT_PART(name, ' ', 1),
            last_name = COALESCE(NULLIF(SPLIT_PART(name, ' ', 2), ''), SPLIT_PART(name, ' ', 1))
        WHERE (first_name IS NULL OR last_name IS NULL) 
        AND name IS NOT NULL;
    END IF;
    
    -- Check if any rows have phone but not phone_number
    IF EXISTS (
        SELECT 1 FROM group_members 
        WHERE phone_number IS NULL AND phone IS NOT NULL
    ) THEN
        UPDATE group_members 
        SET phone_number = phone 
        WHERE phone_number IS NULL AND phone IS NOT NULL;
    END IF;
END $$;

-- Now safe to drop old columns
ALTER TABLE group_members DROP COLUMN IF EXISTS name;
ALTER TABLE group_members DROP COLUMN IF EXISTS phone;


-- ============================================================================
-- TABLE 3: group_loans
-- ============================================================================

-- Rename disbursal_date to disbursement_date (fix typo)
ALTER TABLE group_loans RENAME COLUMN disbursal_date TO disbursement_date;

-- Change disbursement_date from timestamp to date
ALTER TABLE group_loans ALTER COLUMN disbursement_date TYPE date USING disbursement_date::date;

-- Add missing maturity_date column
ALTER TABLE group_loans ADD COLUMN IF NOT EXISTS maturity_date DATE;

-- Rename outstanding_balance to balance_remaining (match ORM)
ALTER TABLE group_loans RENAME COLUMN outstanding_balance TO balance_remaining;

-- Rename total_repaid to total_paid (match ORM)
ALTER TABLE group_loans RENAME COLUMN total_repaid TO total_paid;

-- Make interest_rate_annual and term_months NOT NULL (ORM expects this)
UPDATE group_loans SET interest_rate_annual = 10.00 WHERE interest_rate_annual IS NULL;
UPDATE group_loans SET term_months = 12 WHERE term_months IS NULL;
ALTER TABLE group_loans ALTER COLUMN interest_rate_annual SET NOT NULL;
ALTER TABLE group_loans ALTER COLUMN term_months SET NOT NULL;


-- ============================================================================
-- TABLE 4: meetings
-- ============================================================================

-- Add missing columns that ORM expects
ALTER TABLE meetings ADD COLUMN IF NOT EXISTS agenda TEXT;
ALTER TABLE meetings ADD COLUMN IF NOT EXISTS minutes TEXT;
ALTER TABLE meetings ADD COLUMN IF NOT EXISTS attendance_count INTEGER DEFAULT 0;
ALTER TABLE meetings ADD COLUMN IF NOT EXISTS total_fines_collected NUMERIC(12,2) DEFAULT 0.00;
ALTER TABLE meetings ADD COLUMN IF NOT EXISTS total_loan_repayments NUMERIC(12,2) DEFAULT 0.00;
ALTER TABLE meetings ADD COLUMN IF NOT EXISTS created_by INTEGER;

-- Update existing rows with defaults
UPDATE meetings SET attendance_count = COALESCE(members_present, 0) WHERE attendance_count IS NULL;
UPDATE meetings SET total_fines_collected = 0.00 WHERE total_fines_collected IS NULL;
UPDATE meetings SET total_loan_repayments = 0.00 WHERE total_loan_repayments IS NULL;


-- ============================================================================
-- VERIFICATION QUERIES
-- ============================================================================

-- Verify savings_groups
DO $$
DECLARE
    missing_cols TEXT[];
BEGIN
    SELECT ARRAY_AGG(col) INTO missing_cols
    FROM (VALUES ('loan_balance')) AS expected(col)
    WHERE NOT EXISTS (
        SELECT 1 FROM information_schema.columns 
        WHERE table_name = 'savings_groups' AND column_name = col
    );
    
    IF missing_cols IS NOT NULL THEN
        RAISE EXCEPTION 'savings_groups missing columns: %', missing_cols;
    END IF;
END $$;

-- Verify group_members
DO $$
DECLARE
    missing_cols TEXT[];
    extra_cols TEXT[];
BEGIN
    -- Check for required columns
    SELECT ARRAY_AGG(col) INTO missing_cols
    FROM (VALUES ('first_name'), ('last_name'), ('phone_number'), ('gender'), ('user_id')) AS expected(col)
    WHERE NOT EXISTS (
        SELECT 1 FROM information_schema.columns 
        WHERE table_name = 'group_members' AND column_name = col
    );
    
    IF missing_cols IS NOT NULL THEN
        RAISE EXCEPTION 'group_members missing columns: %', missing_cols;
    END IF;
    
    -- Check that old columns are removed
    SELECT ARRAY_AGG(col) INTO extra_cols
    FROM (VALUES ('name'), ('phone')) AS old(col)
    WHERE EXISTS (
        SELECT 1 FROM information_schema.columns 
        WHERE table_name = 'group_members' AND column_name = col
    );
    
    IF extra_cols IS NOT NULL THEN
        RAISE WARNING 'group_members still has old columns: %', extra_cols;
    END IF;
    
END $$;

-- Verify group_loans
DO $$
DECLARE
    missing_cols TEXT[];
BEGIN
    SELECT ARRAY_AGG(col) INTO missing_cols
    FROM (VALUES ('disbursement_date'), ('maturity_date'), ('balance_remaining'), ('total_paid')) AS expected(col)
    WHERE NOT EXISTS (
        SELECT 1 FROM information_schema.columns 
        WHERE table_name = 'group_loans' AND column_name = col
    );
    
    IF missing_cols IS NOT NULL THEN
        RAISE EXCEPTION 'group_loans missing columns: %', missing_cols;
    END IF;
END $$;

-- Verify meetings
DO $$
DECLARE
    missing_cols TEXT[];
BEGIN
    SELECT ARRAY_AGG(col) INTO missing_cols
    FROM (VALUES ('agenda'), ('minutes'), ('attendance_count'), ('total_fines_collected'), ('total_loan_repayments')) AS expected(col)
    WHERE NOT EXISTS (
        SELECT 1 FROM information_schema.columns 
        WHERE table_name = 'meetings' AND column_name = col
    );
    
    IF missing_cols IS NOT NULL THEN
        RAISE EXCEPTION 'meetings missing columns: %', missing_cols;
    END IF;
END $$;


COMMIT;

