-- Migration 007: Phase 3 - Achievements System
-- Date: 2025-10-24
-- Purpose: Add achievement tracking system with cascading data from Phase 1 & 2

-- ============================================================================
-- TABLE 1: achievements
-- Achievement definitions and criteria
-- ============================================================================
CREATE TABLE IF NOT EXISTS achievements (
    id SERIAL PRIMARY KEY,
    
    -- Basic info
    name VARCHAR(100) NOT NULL UNIQUE,
    description TEXT NOT NULL,
    category VARCHAR(50) NOT NULL,  -- FINANCIAL, LOAN, ATTENDANCE, PARTICIPATION, TRAINING, LEADERSHIP
    
    -- Achievement criteria
    criteria_type VARCHAR(50) NOT NULL,  -- MILESTONE, STREAK, THRESHOLD, COMPLETION
    criteria_value NUMERIC(12, 2),  -- Value to achieve (e.g., 100000 for savings milestone)
    criteria_duration_days INTEGER,  -- Duration for streak achievements
    
    -- Badge/Certificate info
    badge_icon_url VARCHAR(255),
    badge_color VARCHAR(20),  -- HEX color code
    certificate_template_id INTEGER,
    
    -- Points and rewards
    points_awarded INTEGER DEFAULT 0,
    reward_amount NUMERIC(12, 2) DEFAULT 0.00,
    
    -- Status
    is_active BOOLEAN DEFAULT TRUE,
    display_order INTEGER DEFAULT 0,
    
    -- Audit fields
    created_by INTEGER NOT NULL REFERENCES users(id),
    created_date TIMESTAMP DEFAULT NOW(),
    updated_date TIMESTAMP DEFAULT NOW(),
    
    CONSTRAINT check_valid_category CHECK (category IN ('FINANCIAL', 'LOAN', 'ATTENDANCE', 'PARTICIPATION', 'TRAINING', 'LEADERSHIP')),
    CONSTRAINT check_valid_criteria CHECK (criteria_type IN ('MILESTONE', 'STREAK', 'THRESHOLD', 'COMPLETION'))
);

-- ============================================================================
-- TABLE 2: member_achievements
-- Track member achievement awards
-- ============================================================================
CREATE TABLE IF NOT EXISTS member_achievements (
    id SERIAL PRIMARY KEY,
    
    -- References
    member_id INTEGER NOT NULL REFERENCES group_members(id) ON DELETE CASCADE,
    achievement_id INTEGER NOT NULL REFERENCES achievements(id) ON DELETE CASCADE,
    
    -- Achievement details
    achievement_date TIMESTAMP DEFAULT NOW(),
    achievement_count INTEGER DEFAULT 1,  -- For repeatable achievements
    
    -- Points and rewards
    points_earned INTEGER DEFAULT 0,
    reward_received NUMERIC(12, 2) DEFAULT 0.00,
    
    -- Certificate info
    certificate_number VARCHAR(50) UNIQUE,
    certificate_issued_date DATE,
    certificate_expiry_date DATE,
    
    -- Status
    is_verified BOOLEAN DEFAULT FALSE,
    verified_by INTEGER REFERENCES users(id),
    verified_date TIMESTAMP,
    
    -- Audit fields
    created_date TIMESTAMP DEFAULT NOW(),
    updated_date TIMESTAMP DEFAULT NOW(),
    
    UNIQUE(member_id, achievement_id),
    CONSTRAINT check_positive_points CHECK (points_earned >= 0),
    CONSTRAINT check_positive_reward CHECK (reward_received >= 0)
);

-- ============================================================================
-- TABLE 3: achievement_badges
-- Badge and certificate definitions
-- ============================================================================
CREATE TABLE IF NOT EXISTS achievement_badges (
    id SERIAL PRIMARY KEY,
    
    -- Badge info
    name VARCHAR(100) NOT NULL UNIQUE,
    description TEXT,
    badge_type VARCHAR(50) NOT NULL,  -- BADGE, CERTIFICATE, MEDAL, STAR
    
    -- Visual properties
    icon_url VARCHAR(255),
    icon_color VARCHAR(20),
    background_color VARCHAR(20),
    
    -- Badge criteria
    required_achievements INTEGER DEFAULT 1,
    required_points INTEGER DEFAULT 0,
    
    -- Status
    is_active BOOLEAN DEFAULT TRUE,
    display_order INTEGER DEFAULT 0,
    
    -- Audit fields
    created_by INTEGER NOT NULL REFERENCES users(id),
    created_date TIMESTAMP DEFAULT NOW(),
    updated_date TIMESTAMP DEFAULT NOW(),
    
    CONSTRAINT check_valid_badge_type CHECK (badge_type IN ('BADGE', 'CERTIFICATE', 'MEDAL', 'STAR'))
);

-- ============================================================================
-- TABLE 4: member_badges
-- Track member badge awards
-- ============================================================================
CREATE TABLE IF NOT EXISTS member_badges (
    id SERIAL PRIMARY KEY,
    
    -- References
    member_id INTEGER NOT NULL REFERENCES group_members(id) ON DELETE CASCADE,
    badge_id INTEGER NOT NULL REFERENCES achievement_badges(id) ON DELETE CASCADE,
    
    -- Badge award details
    awarded_date TIMESTAMP DEFAULT NOW(),
    awarded_by INTEGER REFERENCES users(id),
    
    -- Status
    is_displayed BOOLEAN DEFAULT TRUE,
    
    -- Audit fields
    created_date TIMESTAMP DEFAULT NOW(),
    
    UNIQUE(member_id, badge_id)
);

-- ============================================================================
-- TABLE 5: achievement_leaderboard
-- Materialized view for leaderboard rankings
-- ============================================================================
CREATE TABLE IF NOT EXISTS achievement_leaderboard (
    id SERIAL PRIMARY KEY,
    
    -- References
    member_id INTEGER NOT NULL REFERENCES group_members(id) ON DELETE CASCADE,
    group_id INTEGER NOT NULL REFERENCES savings_groups(id) ON DELETE CASCADE,
    
    -- Leaderboard metrics
    total_achievements INTEGER DEFAULT 0,
    total_points INTEGER DEFAULT 0,
    total_badges INTEGER DEFAULT 0,
    rank_in_group INTEGER,
    rank_in_system INTEGER,
    
    -- Performance metrics
    achievement_rate NUMERIC(5, 2) DEFAULT 0.00,  -- Percentage
    points_per_month NUMERIC(10, 2) DEFAULT 0.00,
    
    -- Last updated
    last_updated TIMESTAMP DEFAULT NOW(),
    
    UNIQUE(member_id, group_id)
);

-- ============================================================================
-- INDEXES for Performance
-- ============================================================================
CREATE INDEX idx_member_achievements_member_id ON member_achievements(member_id);
CREATE INDEX idx_member_achievements_achievement_id ON member_achievements(achievement_id);
CREATE INDEX idx_member_achievements_date ON member_achievements(achievement_date);
CREATE INDEX idx_member_badges_member_id ON member_badges(member_id);
CREATE INDEX idx_achievement_leaderboard_group_id ON achievement_leaderboard(group_id);
CREATE INDEX idx_achievement_leaderboard_rank ON achievement_leaderboard(rank_in_group);

-- ============================================================================
-- TRIGGERS for Cascading Data
-- ============================================================================

-- Trigger 1: Update leaderboard when achievement is awarded
CREATE OR REPLACE FUNCTION update_leaderboard_on_achievement()
RETURNS TRIGGER AS $$
BEGIN
    UPDATE achievement_leaderboard
    SET 
        total_achievements = (
            SELECT COUNT(*) FROM member_achievements 
            WHERE member_id = NEW.member_id
        ),
        total_points = (
            SELECT COALESCE(SUM(points_earned), 0) FROM member_achievements 
            WHERE member_id = NEW.member_id
        ),
        last_updated = NOW()
    WHERE member_id = NEW.member_id;
    
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER trg_update_leaderboard_on_achievement
AFTER INSERT ON member_achievements
FOR EACH ROW
EXECUTE FUNCTION update_leaderboard_on_achievement();

-- Trigger 2: Create leaderboard entry when member joins group
CREATE OR REPLACE FUNCTION create_leaderboard_entry()
RETURNS TRIGGER AS $$
BEGIN
    INSERT INTO achievement_leaderboard (member_id, group_id)
    VALUES (NEW.id, NEW.group_id)
    ON CONFLICT (member_id, group_id) DO NOTHING;
    
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER trg_create_leaderboard_entry
AFTER INSERT ON group_members
FOR EACH ROW
EXECUTE FUNCTION create_leaderboard_entry();

-- ============================================================================
-- SEED DATA: Default Achievements
-- ============================================================================

-- Financial Achievements
INSERT INTO achievements (name, description, category, criteria_type, criteria_value, badge_icon_url, badge_color, points_awarded, is_active, created_by)
VALUES 
    ('First Savings', 'Make your first savings contribution', 'FINANCIAL', 'MILESTONE', 1000, '/badges/first-savings.png', '#4CAF50', 10, TRUE, 1),
    ('Savings Milestone 50K', 'Reach 50,000 in total savings', 'FINANCIAL', 'THRESHOLD', 50000, '/badges/savings-50k.png', '#4CAF50', 25, TRUE, 1),
    ('Savings Milestone 100K', 'Reach 100,000 in total savings', 'FINANCIAL', 'THRESHOLD', 100000, '/badges/savings-100k.png', '#4CAF50', 50, TRUE, 1),
    ('Savings Milestone 500K', 'Reach 500,000 in total savings', 'FINANCIAL', 'THRESHOLD', 500000, '/badges/savings-500k.png', '#4CAF50', 100, TRUE, 1);

-- Loan Achievements
INSERT INTO achievements (name, description, category, criteria_type, criteria_value, badge_icon_url, badge_color, points_awarded, is_active, created_by)
VALUES 
    ('First Loan', 'Take your first group loan', 'LOAN', 'MILESTONE', 1, '/badges/first-loan.png', '#2196F3', 15, TRUE, 1),
    ('Perfect Repayment', 'Repay a loan on time with no penalties', 'LOAN', 'COMPLETION', 1, '/badges/perfect-repayment.png', '#2196F3', 30, TRUE, 1),
    ('Loan Streak 3', 'Successfully repay 3 loans in a row', 'LOAN', 'STREAK', 3, '/badges/loan-streak-3.png', '#2196F3', 50, TRUE, 1);

-- Attendance Achievements
INSERT INTO achievements (name, description, category, criteria_type, criteria_value, badge_icon_url, badge_color, points_awarded, is_active, created_by)
VALUES 
    ('Perfect Attendance', 'Attend all meetings in a month', 'ATTENDANCE', 'STREAK', 4, '/badges/perfect-attendance.png', '#FF9800', 20, TRUE, 1),
    ('Attendance Streak 90', 'Maintain 90% attendance for 90 days', 'ATTENDANCE', 'STREAK', 90, '/badges/attendance-90.png', '#FF9800', 40, TRUE, 1),
    ('Attendance Milestone', 'Attend 50 meetings', 'ATTENDANCE', 'THRESHOLD', 50, '/badges/attendance-50.png', '#FF9800', 35, TRUE, 1);

-- Participation Achievements
INSERT INTO achievements (name, description, category, criteria_type, criteria_value, badge_icon_url, badge_color, points_awarded, is_active, created_by)
VALUES 
    ('Active Participant', 'Participate in 10 group activities', 'PARTICIPATION', 'THRESHOLD', 10, '/badges/active-participant.png', '#9C27B0', 25, TRUE, 1),
    ('Super Participant', 'Participate in 50 group activities', 'PARTICIPATION', 'THRESHOLD', 50, '/badges/super-participant.png', '#9C27B0', 60, TRUE, 1);

-- Training Achievements
INSERT INTO achievements (name, description, category, criteria_type, criteria_value, badge_icon_url, badge_color, points_awarded, is_active, created_by)
VALUES 
    ('Training Complete', 'Complete financial literacy training', 'TRAINING', 'COMPLETION', 1, '/badges/training-complete.png', '#F44336', 30, TRUE, 1),
    ('Multi-Training', 'Complete 3 different training programs', 'TRAINING', 'THRESHOLD', 3, '/badges/multi-training.png', '#F44336', 50, TRUE, 1);

-- Leadership Achievements
INSERT INTO achievements (name, description, category, criteria_type, criteria_value, badge_icon_url, badge_color, points_awarded, is_active, created_by)
VALUES 
    ('Group Leader', 'Hold a leadership position in the group', 'LEADERSHIP', 'COMPLETION', 1, '/badges/group-leader.png', '#00BCD4', 40, TRUE, 1),
    ('Mentor', 'Help 5 new members get started', 'LEADERSHIP', 'THRESHOLD', 5, '/badges/mentor.png', '#00BCD4', 50, TRUE, 1);

-- ============================================================================
-- SEED DATA: Default Badges
-- ============================================================================

INSERT INTO achievement_badges (name, description, badge_type, icon_url, icon_color, background_color, required_achievements, required_points, is_active, created_by)
VALUES 
    ('Bronze Member', 'Earn 5 achievements', 'MEDAL', '/badges/bronze-medal.png', '#CD7F32', '#FFF8DC', 5, 0, TRUE, 1),
    ('Silver Member', 'Earn 10 achievements', 'MEDAL', '/badges/silver-medal.png', '#C0C0C0', '#F5F5F5', 10, 0, TRUE, 1),
    ('Gold Member', 'Earn 15 achievements', 'MEDAL', '/badges/gold-medal.png', '#FFD700', '#FFFACD', 15, 0, TRUE, 1),
    ('Platinum Member', 'Earn 20 achievements', 'MEDAL', '/badges/platinum-medal.png', '#E5E4E2', '#F0F8FF', 20, 0, TRUE, 1);

-- ============================================================================
-- COMPLETION MESSAGE
-- ============================================================================
-- Migration 007 Complete: Phase 3 Achievements System
-- Tables created: achievements, member_achievements, achievement_badges, member_badges, achievement_leaderboard
-- Triggers created: 2 (leaderboard updates, member entry)
-- Seed data: 20 default achievements + 4 default badges

