-- Migration: 007_add_aggregation_triggers.sql
-- Purpose: Add database triggers for automatic member and group aggregation
-- Date: 2025-10-23

-- ============================================================================
-- TRIGGER 1: Update member aggregation when activity participation changes
-- ============================================================================

CREATE OR REPLACE FUNCTION update_member_aggregation_on_participation()
RETURNS TRIGGER AS $$
BEGIN
    -- Update member's aggregated data when participation changes
    UPDATE group_members
    SET 
        attendance_percentage = (
            SELECT COALESCE(AVG(CASE WHEN ma.attended THEN 100.0 ELSE 0.0 END), 0)
            FROM meeting_attendance ma
            WHERE ma.member_id = NEW.member_id
            AND ma.meeting_date >= CURRENT_DATE - INTERVAL '90 days'
        ),
        is_eligible_for_loans = (
            SELECT COALESCE(AVG(CASE WHEN ma.attended THEN 100.0 ELSE 0.0 END), 0) >= 50
            FROM meeting_attendance ma
            WHERE ma.member_id = NEW.member_id
            AND ma.meeting_date >= CURRENT_DATE - INTERVAL '90 days'
        ),
        updated_date = CURRENT_TIMESTAMP
    WHERE id = NEW.member_id;
    
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- Drop trigger if exists
DROP TRIGGER IF EXISTS trg_update_member_aggregation_on_participation ON member_activity_participation;

-- Create trigger
CREATE TRIGGER trg_update_member_aggregation_on_participation
AFTER INSERT OR UPDATE ON member_activity_participation
FOR EACH ROW
EXECUTE FUNCTION update_member_aggregation_on_participation();

-- ============================================================================
-- TRIGGER 2: Update group aggregation when member aggregation changes
-- ============================================================================

CREATE OR REPLACE FUNCTION update_group_aggregation_on_member_change()
RETURNS TRIGGER AS $$
DECLARE
    v_group_id INTEGER;
    v_total_savings DECIMAL;
    v_total_loans DECIMAL;
    v_avg_attendance DECIMAL;
    v_eligible_count INTEGER;
    v_total_members INTEGER;
    v_health_score DECIMAL;
BEGIN
    -- Get group ID
    SELECT group_id INTO v_group_id FROM group_members WHERE id = NEW.id;
    
    IF v_group_id IS NOT NULL THEN
        -- Calculate group totals
        SELECT 
            COALESCE(SUM(ms.current_balance), 0),
            COALESCE(SUM(gl.amount), 0),
            COALESCE(AVG(gm.attendance_percentage), 0),
            COUNT(CASE WHEN gm.is_eligible_for_loans THEN 1 END),
            COUNT(*)
        INTO 
            v_total_savings,
            v_total_loans,
            v_avg_attendance,
            v_eligible_count,
            v_total_members
        FROM group_members gm
        LEFT JOIN member_savings ms ON gm.id = ms.member_id AND ms.is_active = TRUE
        LEFT JOIN group_loans gl ON gm.id = gl.member_id AND gl.status = 'ACTIVE'
        WHERE gm.group_id = v_group_id AND gm.is_active = TRUE;
        
        -- Calculate health score
        v_health_score := LEAST(100, GREATEST(0, 
            (v_avg_attendance / 100 * 40) +
            (LEAST(100, (v_total_savings / 10000) * 30)) +
            ((CASE WHEN v_total_members > 0 THEN v_eligible_count::DECIMAL / v_total_members * 100 ELSE 0 END) / 100 * 10)
        ));
        
        -- Update group aggregation
        UPDATE savings_groups
        SET 
            current_amount = v_total_savings,
            total_loans_outstanding = v_total_loans,
            health_score = v_health_score,
            updated_date = CURRENT_TIMESTAMP
        WHERE id = v_group_id;
    END IF;
    
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- Drop trigger if exists
DROP TRIGGER IF EXISTS trg_update_group_aggregation_on_member_change ON group_members;

-- Create trigger
CREATE TRIGGER trg_update_group_aggregation_on_member_change
AFTER UPDATE ON group_members
FOR EACH ROW
WHEN (OLD.attendance_percentage IS DISTINCT FROM NEW.attendance_percentage 
   OR OLD.is_eligible_for_loans IS DISTINCT FROM NEW.is_eligible_for_loans)
EXECUTE FUNCTION update_group_aggregation_on_member_change();

-- ============================================================================
-- TRIGGER 3: Update group aggregation when member savings change
-- ============================================================================

CREATE OR REPLACE FUNCTION update_group_aggregation_on_savings_change()
RETURNS TRIGGER AS $$
DECLARE
    v_group_id INTEGER;
    v_total_savings DECIMAL;
BEGIN
    -- Get group ID through member
    SELECT gm.group_id INTO v_group_id
    FROM group_members gm
    WHERE gm.id = NEW.member_id;
    
    IF v_group_id IS NOT NULL THEN
        -- Calculate total group savings
        SELECT COALESCE(SUM(ms.current_balance), 0)
        INTO v_total_savings
        FROM member_savings ms
        JOIN group_members gm ON ms.member_id = gm.id
        WHERE gm.group_id = v_group_id AND ms.is_active = TRUE;
        
        -- Update group
        UPDATE savings_groups
        SET 
            current_amount = v_total_savings,
            updated_date = CURRENT_TIMESTAMP
        WHERE id = v_group_id;
    END IF;
    
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- Drop trigger if exists
DROP TRIGGER IF EXISTS trg_update_group_aggregation_on_savings_change ON member_savings;

-- Create trigger
CREATE TRIGGER trg_update_group_aggregation_on_savings_change
AFTER INSERT OR UPDATE ON member_savings
FOR EACH ROW
EXECUTE FUNCTION update_group_aggregation_on_savings_change();

-- ============================================================================
-- TRIGGER 4: Update group aggregation when loans change
-- ============================================================================

CREATE OR REPLACE FUNCTION update_group_aggregation_on_loans_change()
RETURNS TRIGGER AS $$
DECLARE
    v_group_id INTEGER;
    v_total_loans DECIMAL;
BEGIN
    -- Get group ID through member
    SELECT gm.group_id INTO v_group_id
    FROM group_members gm
    WHERE gm.id = NEW.member_id;
    
    IF v_group_id IS NOT NULL THEN
        -- Calculate total group loans
        SELECT COALESCE(SUM(gl.amount), 0)
        INTO v_total_loans
        FROM group_loans gl
        JOIN group_members gm ON gl.member_id = gm.id
        WHERE gm.group_id = v_group_id AND gl.status = 'ACTIVE';
        
        -- Update group
        UPDATE savings_groups
        SET 
            total_loans_outstanding = v_total_loans,
            updated_date = CURRENT_TIMESTAMP
        WHERE id = v_group_id;
    END IF;
    
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- Drop trigger if exists
DROP TRIGGER IF EXISTS trg_update_group_aggregation_on_loans_change ON group_loans;

-- Create trigger
CREATE TRIGGER trg_update_group_aggregation_on_loans_change
AFTER INSERT OR UPDATE ON group_loans
FOR EACH ROW
EXECUTE FUNCTION update_group_aggregation_on_loans_change();

-- ============================================================================
-- VERIFICATION
-- ============================================================================

-- Verify all triggers are created
SELECT 
    trigger_name,
    event_manipulation,
    event_object_table,
    action_statement
FROM information_schema.triggers
WHERE trigger_schema = 'public'
AND trigger_name LIKE 'trg_update_%'
ORDER BY trigger_name;

