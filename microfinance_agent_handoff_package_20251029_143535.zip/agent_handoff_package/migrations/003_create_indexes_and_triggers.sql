-- ============================================================================
-- MEETING SCHEDULER SYSTEM - INDEXES AND TRIGGERS
-- Migration: 003_create_indexes_and_triggers.sql
-- Description: Creates performance indexes and automated triggers
-- Date: 2025-10-02
-- ============================================================================

BEGIN;

-- ============================================================================
-- PERFORMANCE INDEXES
-- ============================================================================

-- Meeting Invitations Indexes
CREATE INDEX IF NOT EXISTS idx_meeting_invitations_meeting_member 
    ON meeting_invitations(meeting_id, member_id);
CREATE INDEX IF NOT EXISTS idx_meeting_invitations_status 
    ON meeting_invitations(invitation_status);
CREATE INDEX IF NOT EXISTS idx_meeting_invitations_invited_date 
    ON meeting_invitations(invited_date);
CREATE INDEX IF NOT EXISTS idx_meeting_invitations_member_status 
    ON meeting_invitations(member_id, invitation_status);

-- Planned Meeting Activities Indexes
CREATE INDEX IF NOT EXISTS idx_planned_activities_meeting_order 
    ON planned_meeting_activities(meeting_id, activity_order);
CREATE INDEX IF NOT EXISTS idx_planned_activities_type_status 
    ON planned_meeting_activities(activity_type, status);
CREATE INDEX IF NOT EXISTS idx_planned_activities_status 
    ON planned_meeting_activities(status);
CREATE INDEX IF NOT EXISTS idx_planned_activities_meeting 
    ON planned_meeting_activities(meeting_id);

-- Meeting Templates Indexes
CREATE INDEX IF NOT EXISTS idx_meeting_templates_group_active 
    ON meeting_templates(group_id, is_active);
CREATE INDEX IF NOT EXISTS idx_meeting_templates_type 
    ON meeting_templates(meeting_type);
CREATE INDEX IF NOT EXISTS idx_meeting_templates_recurring 
    ON meeting_templates(is_recurring, recurrence_pattern);

-- Meeting Activity Participants Indexes
CREATE INDEX IF NOT EXISTS idx_activity_participants_activity_member 
    ON meeting_activity_participants(planned_activity_id, member_id);
CREATE INDEX IF NOT EXISTS idx_activity_participants_member 
    ON meeting_activity_participants(member_id);
CREATE INDEX IF NOT EXISTS idx_activity_participants_participation 
    ON meeting_activity_participants(actually_participated);

-- Scheduler Calendar Indexes
CREATE INDEX IF NOT EXISTS idx_scheduler_calendar_date_time 
    ON scheduler_calendar(calendar_date, time_slot);
CREATE INDEX IF NOT EXISTS idx_scheduler_calendar_group_date 
    ON scheduler_calendar(group_id, calendar_date);
CREATE INDEX IF NOT EXISTS idx_scheduler_calendar_booking_status 
    ON scheduler_calendar(booking_status, is_available);
CREATE INDEX IF NOT EXISTS idx_scheduler_calendar_meeting 
    ON scheduler_calendar(meeting_id);
CREATE INDEX IF NOT EXISTS idx_scheduler_calendar_recurring 
    ON scheduler_calendar(is_recurring, recurrence_id);

-- Enhanced Meetings Table Indexes
CREATE INDEX IF NOT EXISTS idx_meetings_scheduled_by 
    ON meetings(scheduled_by);
CREATE INDEX IF NOT EXISTS idx_meetings_template 
    ON meetings(meeting_template_id);
CREATE INDEX IF NOT EXISTS idx_meetings_recurring 
    ON meetings(is_recurring_instance, recurrence_id);
CREATE INDEX IF NOT EXISTS idx_meetings_date_group 
    ON meetings(meeting_date, group_id);

-- Enhanced Meeting Attendance Indexes
CREATE INDEX IF NOT EXISTS idx_attendance_activity_participation 
    ON meeting_attendance(activity_participation_score);
CREATE INDEX IF NOT EXISTS idx_attendance_savings_contributed 
    ON meeting_attendance(savings_contributed, savings_amount);
CREATE INDEX IF NOT EXISTS idx_attendance_method 
    ON meeting_attendance(attendance_method);
CREATE INDEX IF NOT EXISTS idx_attendance_check_in_time 
    ON meeting_attendance(check_in_time);

-- Enhanced Group Members Indexes
CREATE INDEX IF NOT EXISTS idx_group_members_attendance_percentage 
    ON group_members(attendance_percentage);
CREATE INDEX IF NOT EXISTS idx_group_members_loan_eligibility 
    ON group_members(is_eligible_for_loans);
CREATE INDEX IF NOT EXISTS idx_group_members_attendance_update 
    ON group_members(last_attendance_update);

-- Enhanced Savings Groups Indexes
CREATE INDEX IF NOT EXISTS idx_savings_groups_region_district 
    ON savings_groups(region, district);
CREATE INDEX IF NOT EXISTS idx_savings_groups_geographic 
    ON savings_groups(latitude, longitude);
CREATE INDEX IF NOT EXISTS idx_savings_groups_cycle 
    ON savings_groups(current_cycle_number, cycle_duration_months);
CREATE INDEX IF NOT EXISTS idx_savings_groups_credit_score 
    ON savings_groups(credit_score);
CREATE INDEX IF NOT EXISTS idx_savings_groups_third_year 
    ON savings_groups(is_in_third_year);

-- ============================================================================
-- AUTOMATED TRIGGERS FOR DATA CONSISTENCY
-- ============================================================================

-- Function to update attendance percentage when attendance changes
CREATE OR REPLACE FUNCTION update_member_attendance_percentage()
RETURNS TRIGGER AS $$
BEGIN
    -- Update attendance statistics for the affected member
    UPDATE group_members SET
        total_meetings_attended = (
            SELECT COUNT(*) 
            FROM meeting_attendance 
            WHERE member_id = COALESCE(NEW.member_id, OLD.member_id) 
            AND attended = TRUE
        ),
        total_meetings_eligible = (
            SELECT COUNT(*) 
            FROM meeting_attendance 
            WHERE member_id = COALESCE(NEW.member_id, OLD.member_id)
        ),
        last_attendance_update = CURRENT_TIMESTAMP
    WHERE id = COALESCE(NEW.member_id, OLD.member_id);
    
    -- Calculate attendance percentage
    UPDATE group_members SET
        attendance_percentage = CASE 
            WHEN total_meetings_eligible > 0 THEN 
                ROUND((total_meetings_attended::DECIMAL / total_meetings_eligible::DECIMAL) * 100, 2)
            ELSE 0 
        END,
        is_eligible_for_loans = CASE 
            WHEN total_meetings_eligible > 0 THEN 
                (total_meetings_attended::DECIMAL / total_meetings_eligible::DECIMAL) >= 0.5
            ELSE FALSE 
        END,
        loan_eligibility_reason = CASE 
            WHEN total_meetings_eligible = 0 THEN 'No meetings attended yet'
            WHEN (total_meetings_attended::DECIMAL / total_meetings_eligible::DECIMAL) >= 0.5 THEN 
                'Meets attendance requirement (' || 
                ROUND((total_meetings_attended::DECIMAL / total_meetings_eligible::DECIMAL) * 100, 1) || '%)'
            ELSE 'Below 50% attendance requirement (' || 
                ROUND((total_meetings_attended::DECIMAL / total_meetings_eligible::DECIMAL) * 100, 1) || '%)'
        END
    WHERE id = COALESCE(NEW.member_id, OLD.member_id);
    
    RETURN COALESCE(NEW, OLD);
END;
$$ LANGUAGE plpgsql;

-- Trigger for attendance updates
DROP TRIGGER IF EXISTS trigger_update_attendance_percentage ON meeting_attendance;
CREATE TRIGGER trigger_update_attendance_percentage
    AFTER INSERT OR UPDATE OR DELETE ON meeting_attendance
    FOR EACH ROW
    EXECUTE FUNCTION update_member_attendance_percentage();

-- Function to auto-update meeting template timestamp
CREATE OR REPLACE FUNCTION update_template_timestamp()
RETURNS TRIGGER AS $$
BEGIN
    NEW.updated_date = CURRENT_TIMESTAMP;
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- Trigger for template updates
DROP TRIGGER IF EXISTS trigger_update_template_timestamp ON meeting_templates;
CREATE TRIGGER trigger_update_template_timestamp
    BEFORE UPDATE ON meeting_templates
    FOR EACH ROW
    EXECUTE FUNCTION update_template_timestamp();

-- Function to auto-update planned activity timestamp
CREATE OR REPLACE FUNCTION update_planned_activity_timestamp()
RETURNS TRIGGER AS $$
BEGIN
    NEW.updated_date = CURRENT_TIMESTAMP;
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- Trigger for planned activity updates
DROP TRIGGER IF EXISTS trigger_update_planned_activity_timestamp ON planned_meeting_activities;
CREATE TRIGGER trigger_update_planned_activity_timestamp
    BEFORE UPDATE ON planned_meeting_activities
    FOR EACH ROW
    EXECUTE FUNCTION update_planned_activity_timestamp();

-- Function to auto-update scheduler calendar timestamp
CREATE OR REPLACE FUNCTION update_scheduler_calendar_timestamp()
RETURNS TRIGGER AS $$
BEGIN
    NEW.updated_date = CURRENT_TIMESTAMP;
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- Trigger for scheduler calendar updates
DROP TRIGGER IF EXISTS trigger_update_scheduler_calendar_timestamp ON scheduler_calendar;
CREATE TRIGGER trigger_update_scheduler_calendar_timestamp
    BEFORE UPDATE ON scheduler_calendar
    FOR EACH ROW
    EXECUTE FUNCTION update_scheduler_calendar_timestamp();

-- Function to auto-update activity participant timestamp
CREATE OR REPLACE FUNCTION update_activity_participant_timestamp()
RETURNS TRIGGER AS $$
BEGIN
    NEW.updated_date = CURRENT_TIMESTAMP;
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- Trigger for activity participant updates
DROP TRIGGER IF EXISTS trigger_update_activity_participant_timestamp ON meeting_activity_participants;
CREATE TRIGGER trigger_update_activity_participant_timestamp
    BEFORE UPDATE ON meeting_activity_participants
    FOR EACH ROW
    EXECUTE FUNCTION update_activity_participant_timestamp();

-- ============================================================================
-- DATA VALIDATION FUNCTIONS
-- ============================================================================

-- Function to validate meeting scheduling conflicts
CREATE OR REPLACE FUNCTION check_meeting_scheduling_conflicts()
RETURNS TRIGGER AS $$
DECLARE
    conflict_count INTEGER;
BEGIN
    -- Check for scheduling conflicts
    SELECT COUNT(*) INTO conflict_count
    FROM scheduler_calendar
    WHERE calendar_date = NEW.calendar_date
    AND time_slot = NEW.time_slot
    AND group_id = NEW.group_id
    AND booking_status = 'BOOKED'
    AND id != COALESCE(NEW.id, 0);
    
    IF conflict_count > 0 THEN
        NEW.has_conflicts = TRUE;
        NEW.conflict_notes = 'Scheduling conflict detected with existing meeting';
    ELSE
        NEW.has_conflicts = FALSE;
        NEW.conflict_notes = NULL;
    END IF;
    
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- Trigger for conflict detection
DROP TRIGGER IF EXISTS trigger_check_scheduling_conflicts ON scheduler_calendar;
CREATE TRIGGER trigger_check_scheduling_conflicts
    BEFORE INSERT OR UPDATE ON scheduler_calendar
    FOR EACH ROW
    EXECUTE FUNCTION check_meeting_scheduling_conflicts();

COMMIT;
