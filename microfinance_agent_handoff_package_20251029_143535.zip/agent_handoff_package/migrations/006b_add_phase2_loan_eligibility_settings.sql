-- Migration 006: Phase 2 - Loan Eligibility Settings
-- Adds configurable loan eligibility settings for both individual members and mature groups
-- Date: 2025-10-23

-- ============================================================================
-- 1. INDIVIDUAL MEMBER LOAN ELIGIBILITY SETTINGS
-- ============================================================================

-- Drop existing tables if they exist (for clean migration)
DROP TABLE IF EXISTS loan_eligibility_audit_log CASCADE;
DROP TABLE IF EXISTS group_record_keeping_verification CASCADE;
DROP TABLE IF EXISTS member_internal_loan_participation CASCADE;
DROP TABLE IF EXISTS loan_guarantors CASCADE;
DROP TABLE IF EXISTS mature_group_loans CASCADE;
DROP TABLE IF EXISTS loan_eligibility_settings CASCADE;

CREATE TABLE IF NOT EXISTS loan_eligibility_settings (
    id SERIAL PRIMARY KEY,
    group_id INTEGER NOT NULL REFERENCES savings_groups(id) ON DELETE CASCADE,
    
    -- Individual Member Loan Settings (editable by admin)
    min_attendance_percentage NUMERIC(5,2) DEFAULT 50.00 CHECK (min_attendance_percentage >= 0 AND min_attendance_percentage <= 100),
    min_savings_balance NUMERIC(12,2) DEFAULT 0.00 CHECK (min_savings_balance >= 0),
    min_months_active INTEGER DEFAULT 3 CHECK (min_months_active > 0),
    loan_multiplier NUMERIC(5,2) DEFAULT 3.00 CHECK (loan_multiplier > 0),
    max_loan_amount NUMERIC(12,2) DEFAULT 1000000.00 CHECK (max_loan_amount > 0),
    
    -- Mature Group Loan Settings (editable by admin)
    enable_mature_group_loans BOOLEAN DEFAULT FALSE,
    min_group_cycles INTEGER DEFAULT 3 CHECK (min_group_cycles > 0),
    require_member_guarantee BOOLEAN DEFAULT TRUE,
    require_100_percent_agreement BOOLEAN DEFAULT TRUE,
    require_training_completion BOOLEAN DEFAULT TRUE,
    min_internal_loan_participation_percentage NUMERIC(5,2) DEFAULT 75.00 CHECK (min_internal_loan_participation_percentage >= 0 AND min_internal_loan_participation_percentage <= 100),
    
    -- Record Keeping Verification
    require_good_record_keeping BOOLEAN DEFAULT TRUE,
    
    -- Audit fields
    created_by INTEGER NOT NULL REFERENCES users(id),
    created_date TIMESTAMP DEFAULT NOW(),
    updated_by INTEGER REFERENCES users(id),
    updated_date TIMESTAMP DEFAULT NOW(),
    
    UNIQUE(group_id)
);

CREATE INDEX idx_loan_eligibility_settings_group_id ON loan_eligibility_settings(group_id);

-- ============================================================================
-- 2. MATURE GROUP LOAN TRACKING
-- ============================================================================

CREATE TABLE IF NOT EXISTS mature_group_loans (
    id SERIAL PRIMARY KEY,
    group_id INTEGER NOT NULL REFERENCES savings_groups(id) ON DELETE CASCADE,
    loan_id INTEGER NOT NULL REFERENCES group_loans(id) ON DELETE CASCADE,
    
    -- Loan Type
    is_group_loan BOOLEAN DEFAULT TRUE,
    
    -- Member Guarantee Tracking
    member_guarantee_enabled BOOLEAN DEFAULT FALSE,
    guarantor_members TEXT, -- JSON array of member IDs who guarantee the loan
    
    -- Cycle Verification
    group_cycle_at_loan_time INTEGER NOT NULL,
    meets_cycle_requirement BOOLEAN DEFAULT FALSE,
    
    -- Record Keeping Verification
    has_good_record_keeping BOOLEAN DEFAULT FALSE,
    record_keeping_verified_date TIMESTAMP,
    record_keeping_verified_by INTEGER REFERENCES users(id),
    
    -- Member Agreement Voting
    requires_member_vote BOOLEAN DEFAULT TRUE,
    member_vote_passed BOOLEAN DEFAULT FALSE,
    member_vote_date TIMESTAMP,
    members_voted_yes INTEGER DEFAULT 0,
    members_voted_no INTEGER DEFAULT 0,
    members_abstained INTEGER DEFAULT 0,
    
    -- Internal Loan Participation Tracking
    internal_loan_participation_percentage NUMERIC(5,2) DEFAULT 0.00,
    meets_participation_requirement BOOLEAN DEFAULT FALSE,
    
    -- Training Completion
    training_completion_verified BOOLEAN DEFAULT FALSE,
    training_completion_verified_date TIMESTAMP,
    training_completion_verified_by INTEGER REFERENCES users(id),
    
    -- CIGA (Collective Income Generating Activity) Attachment
    ciga_id INTEGER REFERENCES iga_activities(id),
    ciga_attached BOOLEAN DEFAULT FALSE,
    ciga_attachment_date TIMESTAMP,
    
    -- Audit fields
    created_date TIMESTAMP DEFAULT NOW(),
    updated_date TIMESTAMP DEFAULT NOW(),
    
    UNIQUE(group_id, loan_id)
);

CREATE INDEX idx_mature_group_loans_group_id ON mature_group_loans(group_id);
CREATE INDEX idx_mature_group_loans_loan_id ON mature_group_loans(loan_id);
CREATE INDEX idx_mature_group_loans_ciga_id ON mature_group_loans(ciga_id);

-- ============================================================================
-- 3. MEMBER GUARANTEE TRACKING
-- ============================================================================

CREATE TABLE IF NOT EXISTS loan_guarantors (
    id SERIAL PRIMARY KEY,
    mature_group_loan_id INTEGER NOT NULL REFERENCES mature_group_loans(id) ON DELETE CASCADE,
    guarantor_member_id INTEGER NOT NULL REFERENCES group_members(id) ON DELETE CASCADE,
    
    -- Guarantee Details
    guarantee_amount NUMERIC(12,2) NOT NULL CHECK (guarantee_amount > 0),
    guarantee_date TIMESTAMP DEFAULT NOW(),
    
    -- Guarantee Status
    status TEXT DEFAULT 'ACTIVE' CHECK (status IN ('ACTIVE', 'RELEASED', 'CLAIMED', 'WAIVED')),
    status_changed_date TIMESTAMP,
    
    -- Audit fields
    created_date TIMESTAMP DEFAULT NOW(),
    updated_date TIMESTAMP DEFAULT NOW(),
    
    UNIQUE(mature_group_loan_id, guarantor_member_id)
);

CREATE INDEX idx_loan_guarantors_mature_group_loan_id ON loan_guarantors(mature_group_loan_id);
CREATE INDEX idx_loan_guarantors_guarantor_member_id ON loan_guarantors(guarantor_member_id);

-- ============================================================================
-- 4. MEMBER INTERNAL LOAN PARTICIPATION TRACKING
-- ============================================================================

CREATE TABLE IF NOT EXISTS member_internal_loan_participation (
    id SERIAL PRIMARY KEY,
    group_id INTEGER NOT NULL REFERENCES savings_groups(id) ON DELETE CASCADE,
    member_id INTEGER NOT NULL REFERENCES group_members(id) ON DELETE CASCADE,
    mature_group_loan_id INTEGER REFERENCES mature_group_loans(id) ON DELETE SET NULL,
    
    -- Participation Details
    plans_to_take_internal_loan BOOLEAN DEFAULT FALSE,
    plans_to_invest_in_iga BOOLEAN DEFAULT FALSE,
    participation_date TIMESTAMP DEFAULT NOW(),
    
    -- Audit fields
    created_date TIMESTAMP DEFAULT NOW(),
    updated_date TIMESTAMP DEFAULT NOW(),
    
    UNIQUE(group_id, member_id, mature_group_loan_id)
);

CREATE INDEX idx_member_internal_loan_participation_group_id ON member_internal_loan_participation(group_id);
CREATE INDEX idx_member_internal_loan_participation_member_id ON member_internal_loan_participation(member_id);
CREATE INDEX idx_member_internal_loan_participation_mature_group_loan_id ON member_internal_loan_participation(mature_group_loan_id);

-- ============================================================================
-- 5. GROUP RECORD KEEPING VERIFICATION
-- ============================================================================

CREATE TABLE IF NOT EXISTS group_record_keeping_verification (
    id SERIAL PRIMARY KEY,
    group_id INTEGER NOT NULL REFERENCES savings_groups(id) ON DELETE CASCADE,
    
    -- Passbook Status
    has_passbooks BOOLEAN DEFAULT FALSE,
    passbooks_in_order BOOLEAN DEFAULT FALSE,
    passbook_verification_date TIMESTAMP,
    
    -- Group Ledger Status
    has_group_ledger BOOLEAN DEFAULT FALSE,
    ledger_in_order BOOLEAN DEFAULT FALSE,
    ledger_verification_date TIMESTAMP,
    
    -- Cashbook Status
    has_cashbook BOOLEAN DEFAULT FALSE,
    cashbook_in_order BOOLEAN DEFAULT FALSE,
    cashbook_verification_date TIMESTAMP,
    
    -- Overall Status
    overall_record_keeping_status TEXT DEFAULT 'PENDING' CHECK (overall_record_keeping_status IN ('PENDING', 'VERIFIED', 'NEEDS_IMPROVEMENT', 'EXCELLENT')),
    verification_date TIMESTAMP,
    verified_by INTEGER REFERENCES users(id),
    
    -- Notes
    verification_notes TEXT,
    
    -- Audit fields
    created_date TIMESTAMP DEFAULT NOW(),
    updated_date TIMESTAMP DEFAULT NOW(),
    
    UNIQUE(group_id)
);

CREATE INDEX idx_group_record_keeping_verification_group_id ON group_record_keeping_verification(group_id);

-- ============================================================================
-- 6. LOAN ELIGIBILITY AUDIT LOG
-- ============================================================================

CREATE TABLE IF NOT EXISTS loan_eligibility_audit_log (
    id SERIAL PRIMARY KEY,
    group_id INTEGER NOT NULL REFERENCES savings_groups(id) ON DELETE CASCADE,
    member_id INTEGER REFERENCES group_members(id) ON DELETE SET NULL,
    loan_id INTEGER REFERENCES group_loans(id) ON DELETE SET NULL,
    
    -- Audit Details
    action TEXT NOT NULL,
    eligibility_check_type TEXT NOT NULL CHECK (eligibility_check_type IN ('INDIVIDUAL_MEMBER', 'MATURE_GROUP')),
    result TEXT NOT NULL CHECK (result IN ('ELIGIBLE', 'INELIGIBLE', 'PENDING')),
    
    -- Details
    details TEXT, -- JSON field for detailed eligibility criteria
    
    -- Audit fields
    checked_by INTEGER NOT NULL REFERENCES users(id),
    created_date TIMESTAMP DEFAULT NOW()
);

CREATE INDEX idx_loan_eligibility_audit_log_group_id ON loan_eligibility_audit_log(group_id);
CREATE INDEX idx_loan_eligibility_audit_log_member_id ON loan_eligibility_audit_log(member_id);
CREATE INDEX idx_loan_eligibility_audit_log_loan_id ON loan_eligibility_audit_log(loan_id);

-- ============================================================================
-- 7. INITIALIZE DEFAULT SETTINGS FOR EXISTING GROUPS
-- ============================================================================

INSERT INTO loan_eligibility_settings (group_id, created_by)
SELECT id, 1 FROM savings_groups
WHERE id NOT IN (SELECT group_id FROM loan_eligibility_settings)
ON CONFLICT (group_id) DO NOTHING;

-- ============================================================================
-- 8. INITIALIZE RECORD KEEPING VERIFICATION FOR EXISTING GROUPS
-- ============================================================================

INSERT INTO group_record_keeping_verification (group_id)
SELECT id FROM savings_groups
WHERE id NOT IN (SELECT group_id FROM group_record_keeping_verification)
ON CONFLICT (group_id) DO NOTHING;

-- ============================================================================
-- Migration Complete
-- ============================================================================

