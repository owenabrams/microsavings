-- Migration: 006_harmonize_activity_types.sql
-- Purpose: Standardize activity types to canonical types across the system
-- Date: 2025-10-23
-- Status: Phase 1 - Activity Type Harmonization

-- ============================================================================
-- STEP 1: Migrate existing records to canonical types
-- ============================================================================

-- Migrate savings_collection and INDIVIDUAL_SAVINGS to PERSONAL_SAVINGS
UPDATE meeting_activities
SET activity_type = 'PERSONAL_SAVINGS'
WHERE activity_type IN ('savings_collection', 'INDIVIDUAL_SAVINGS', 'PERSONAL_SAVINGS');

-- Migrate emergency_fund_contribution and GROUP_SAVINGS to ECD_FUND
UPDATE meeting_activities
SET activity_type = 'ECD_FUND'
WHERE activity_type IN ('emergency_fund_contribution', 'GROUP_SAVINGS', 'ecd_fund_contribution');

-- Migrate social_fund_collection to SOCIAL_FUND
UPDATE meeting_activities
SET activity_type = 'SOCIAL_FUND'
WHERE activity_type IN ('social_fund_collection', 'SOCIAL_FUND');

-- Migrate target_fund_contribution to TARGET_SAVINGS
UPDATE meeting_activities
SET activity_type = 'TARGET_SAVINGS'
WHERE activity_type IN ('target_fund_contribution', 'TARGET_SAVINGS');

-- Migrate loan_disbursement to LOAN_DISBURSEMENT
UPDATE meeting_activities
SET activity_type = 'LOAN_DISBURSEMENT'
WHERE activity_type IN ('loan_disbursement', 'LOAN_DISBURSEMENT');

-- Migrate loan_repayment to LOAN_REPAYMENT
UPDATE meeting_activities
SET activity_type = 'LOAN_REPAYMENT'
WHERE activity_type IN ('loan_repayment', 'LOAN_REPAYMENT');

-- Migrate fine_collection to FINE_COLLECTION
UPDATE meeting_activities
SET activity_type = 'FINE_COLLECTION'
WHERE activity_type IN ('fine_collection', 'FINES', 'FINE_COLLECTION');

-- Migrate training_session to TRAINING_SESSION
UPDATE meeting_activities
SET activity_type = 'TRAINING_SESSION'
WHERE activity_type IN ('training_session', 'TRAINING', 'TRAINING_SESSION');

-- Migrate LOAN_APPLICATION to LOAN_APPLICATION (already correct)
UPDATE meeting_activities
SET activity_type = 'LOAN_APPLICATION'
WHERE activity_type IN ('LOAN_APPLICATION', 'LOAN_APPLICATIONS');

-- Migrate AOB to AOB (already correct)
UPDATE meeting_activities
SET activity_type = 'AOB'
WHERE activity_type IN ('AOB');

-- Migrate ATTENDANCE to ATTENDANCE_CHECK
UPDATE meeting_activities
SET activity_type = 'ATTENDANCE_CHECK'
WHERE activity_type IN ('ATTENDANCE', 'ATTENDANCE_CHECK');

-- Migrate MINUTES_REVIEW to MINUTES_REVIEW (already correct)
UPDATE meeting_activities
SET activity_type = 'MINUTES_REVIEW'
WHERE activity_type IN ('MINUTES_REVIEW');

-- ============================================================================
-- STEP 2: Add constraint to enforce canonical types
-- ============================================================================

-- Note: The constraint is already defined in the SQLAlchemy model
-- This migration ensures all existing data conforms to the constraint
-- If you need to add the constraint manually, uncomment below:

-- ALTER TABLE meeting_activities
-- DROP CONSTRAINT IF EXISTS check_valid_activity_type;
-- 
-- ALTER TABLE meeting_activities
-- ADD CONSTRAINT check_valid_activity_type CHECK (
--     activity_type IN (
--         'OPENING_PRAYER', 'ATTENDANCE_CHECK', 'MINUTES_REVIEW',
--         'PERSONAL_SAVINGS', 'ECD_FUND', 'SOCIAL_FUND', 'TARGET_SAVINGS',
--         'LOAN_APPLICATION', 'LOAN_DISBURSEMENT', 'LOAN_REPAYMENT',
--         'FINE_COLLECTION', 'VOTING_SESSION', 'TRAINING_SESSION',
--         'AOB', 'CLOSING_PRAYER'
--     )
-- );

-- ============================================================================
-- STEP 3: Verify migration
-- ============================================================================

-- Check for any non-canonical activity types (should return 0 rows)
-- SELECT DISTINCT activity_type FROM meeting_activities
-- WHERE activity_type NOT IN (
--     'OPENING_PRAYER', 'ATTENDANCE_CHECK', 'MINUTES_REVIEW',
--     'PERSONAL_SAVINGS', 'ECD_FUND', 'SOCIAL_FUND', 'TARGET_SAVINGS',
--     'LOAN_APPLICATION', 'LOAN_DISBURSEMENT', 'LOAN_REPAYMENT',
--     'FINE_COLLECTION', 'VOTING_SESSION', 'TRAINING_SESSION',
--     'AOB', 'CLOSING_PRAYER'
-- );

-- ============================================================================
-- CANONICAL ACTIVITY TYPES (15 total)
-- ============================================================================
-- MEETING_WORKFLOW (Structural):
--   - OPENING_PRAYER
--   - ATTENDANCE_CHECK
--   - MINUTES_REVIEW
--   - CLOSING_PRAYER
--
-- FINANCIAL_ACTIVITIES (Money-related):
--   - PERSONAL_SAVINGS
--   - ECD_FUND
--   - SOCIAL_FUND
--   - TARGET_SAVINGS
--   - LOAN_APPLICATION
--   - LOAN_DISBURSEMENT
--   - LOAN_REPAYMENT
--   - FINE_COLLECTION
--
-- GOVERNANCE_ACTIVITIES (Decision-making):
--   - VOTING_SESSION
--   - TRAINING_SESSION
--   - AOB (Any Other Business)
-- ============================================================================

