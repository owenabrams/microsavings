-- Migration 008: Add Phase 4 Analytics Tables
-- Date: 2025-10-24
-- Purpose: Create analytics tables for aggregating data from all previous phases

-- ============================================================================
-- ANALYTICS SNAPSHOTS TABLE
-- ============================================================================
-- Stores daily snapshots of key metrics for trend analysis and reporting

CREATE TABLE IF NOT EXISTS analytics_snapshots (
    id SERIAL PRIMARY KEY,
    group_id INTEGER NOT NULL,
    snapshot_date DATE NOT NULL,
    
    -- Member Metrics
    total_members INTEGER DEFAULT 0,
    active_members INTEGER DEFAULT 0,
    new_members_this_period INTEGER DEFAULT 0,
    
    -- Financial Metrics
    total_savings NUMERIC(12, 2) DEFAULT 0,
    total_contributions NUMERIC(12, 2) DEFAULT 0,
    avg_savings_per_member NUMERIC(12, 2) DEFAULT 0,
    savings_growth_rate NUMERIC(5, 2) DEFAULT 0,
    
    -- Loan Metrics
    total_loans_issued NUMERIC(12, 2) DEFAULT 0,
    total_loans_repaid NUMERIC(12, 2) DEFAULT 0,
    total_loans_outstanding NUMERIC(12, 2) DEFAULT 0,
    loan_repayment_rate NUMERIC(5, 2) DEFAULT 0,
    loan_default_rate NUMERIC(5, 2) DEFAULT 0,
    
    -- IGA Metrics
    total_iga_cashflow NUMERIC(12, 2) DEFAULT 0,
    total_iga_returns NUMERIC(12, 2) DEFAULT 0,
    
    -- Achievement Metrics
    total_achievements_earned INTEGER DEFAULT 0,
    avg_achievements_per_member NUMERIC(5, 2) DEFAULT 0,
    total_points_earned INTEGER DEFAULT 0,
    
    -- Meeting Metrics
    total_meetings_held INTEGER DEFAULT 0,
    avg_attendance_rate NUMERIC(5, 2) DEFAULT 0,
    
    -- Group Health Score (0-100)
    group_health_score NUMERIC(5, 2) DEFAULT 0,
    
    -- Audit Fields
    created_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    
    -- Constraints
    FOREIGN KEY (group_id) REFERENCES savings_groups(id) ON DELETE CASCADE,
    UNIQUE(group_id, snapshot_date)
);

CREATE INDEX idx_analytics_snapshots_group_date ON analytics_snapshots(group_id, snapshot_date);
CREATE INDEX idx_analytics_snapshots_date ON analytics_snapshots(snapshot_date);

-- ============================================================================
-- ANALYTICS REPORTS TABLE
-- ============================================================================
-- Stores generated reports for different analytics views

CREATE TABLE IF NOT EXISTS analytics_reports (
    id SERIAL PRIMARY KEY,
    group_id INTEGER NOT NULL,
    report_type VARCHAR(50) NOT NULL,  -- FINANCIAL, LOAN, ACHIEVEMENT, GROUP, CUSTOM
    report_name VARCHAR(100) NOT NULL,
    report_description TEXT,
    
    -- Report Data (JSON for flexibility)
    report_data JSONB,
    
    -- Report Parameters
    start_date DATE,
    end_date DATE,
    
    -- Report Status
    status VARCHAR(20) DEFAULT 'COMPLETED',  -- PENDING, COMPLETED, FAILED
    
    -- Audit Fields
    created_by INTEGER,
    created_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    
    -- Constraints
    FOREIGN KEY (group_id) REFERENCES savings_groups(id) ON DELETE CASCADE,
    FOREIGN KEY (created_by) REFERENCES users(id) ON DELETE SET NULL
);

CREATE INDEX idx_analytics_reports_group_type ON analytics_reports(group_id, report_type);
CREATE INDEX idx_analytics_reports_date ON analytics_reports(created_date);

-- ============================================================================
-- MEMBER ANALYTICS TABLE
-- ============================================================================
-- Stores member-level analytics for individual tracking

CREATE TABLE IF NOT EXISTS member_analytics (
    id SERIAL PRIMARY KEY,
    member_id INTEGER NOT NULL,
    group_id INTEGER NOT NULL,
    analytics_date DATE NOT NULL,
    
    -- Financial Metrics
    total_savings NUMERIC(12, 2) DEFAULT 0,
    total_contributions NUMERIC(12, 2) DEFAULT 0,
    savings_trend NUMERIC(5, 2) DEFAULT 0,
    
    -- Loan Metrics
    total_loans_taken NUMERIC(12, 2) DEFAULT 0,
    total_loans_repaid NUMERIC(12, 2) DEFAULT 0,
    loan_repayment_rate NUMERIC(5, 2) DEFAULT 0,
    
    -- Achievement Metrics
    total_achievements INTEGER DEFAULT 0,
    total_points INTEGER DEFAULT 0,
    total_badges INTEGER DEFAULT 0,
    
    -- Participation Metrics
    meetings_attended INTEGER DEFAULT 0,
    meetings_total INTEGER DEFAULT 0,
    attendance_rate NUMERIC(5, 2) DEFAULT 0,
    
    -- Member Score (0-100)
    member_score NUMERIC(5, 2) DEFAULT 0,
    
    -- Audit Fields
    created_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    
    -- Constraints
    FOREIGN KEY (member_id) REFERENCES group_members(id) ON DELETE CASCADE,
    FOREIGN KEY (group_id) REFERENCES savings_groups(id) ON DELETE CASCADE,
    UNIQUE(member_id, analytics_date)
);

CREATE INDEX idx_member_analytics_member_date ON member_analytics(member_id, analytics_date);
CREATE INDEX idx_member_analytics_group_date ON member_analytics(group_id, analytics_date);

-- ============================================================================
-- ANALYTICS AGGREGATION FUNCTION
-- ============================================================================
-- Function to calculate group health score

CREATE OR REPLACE FUNCTION calculate_group_health_score(p_group_id INTEGER)
RETURNS NUMERIC AS $$
DECLARE
    v_member_count INTEGER;
    v_savings_score NUMERIC;
    v_loan_score NUMERIC;
    v_achievement_score NUMERIC;
    v_attendance_score NUMERIC;
    v_health_score NUMERIC;
BEGIN
    -- Get member count
    SELECT COUNT(*) INTO v_member_count FROM group_members WHERE group_id = p_group_id;
    
    IF v_member_count = 0 THEN
        RETURN 0;
    END IF;
    
    -- Calculate savings score (0-25)
    SELECT COALESCE(MIN(25, (SUM(COALESCE(amount, 0)) / (v_member_count * 1000)) * 25), 0)
    INTO v_savings_score
    FROM member_savings
    WHERE member_id IN (SELECT id FROM group_members WHERE group_id = p_group_id);
    
    -- Calculate loan score (0-25)
    SELECT COALESCE(MIN(25, (COUNT(*) / v_member_count) * 25), 0)
    INTO v_loan_score
    FROM group_loans
    WHERE group_id = p_group_id AND status = 'REPAID';
    
    -- Calculate achievement score (0-25)
    SELECT COALESCE(MIN(25, (COUNT(*) / v_member_count) * 25), 0)
    INTO v_achievement_score
    FROM member_achievements
    WHERE member_id IN (SELECT id FROM group_members WHERE group_id = p_group_id);
    
    -- Calculate attendance score (0-25)
    SELECT COALESCE(MIN(25, (COUNT(*) / (v_member_count * 10)) * 25), 0)
    INTO v_attendance_score
    FROM meeting_attendance
    WHERE member_id IN (SELECT id FROM group_members WHERE group_id = p_group_id)
    AND status = 'PRESENT';
    
    -- Calculate total health score
    v_health_score := COALESCE(v_savings_score, 0) + 
                      COALESCE(v_loan_score, 0) + 
                      COALESCE(v_achievement_score, 0) + 
                      COALESCE(v_attendance_score, 0);
    
    RETURN LEAST(100, v_health_score);
END;
$$ LANGUAGE plpgsql;

-- ============================================================================
-- TRIGGER: Create daily analytics snapshot
-- ============================================================================

CREATE OR REPLACE FUNCTION create_daily_analytics_snapshot()
RETURNS TRIGGER AS $$
BEGIN
    -- This function would be called daily via a scheduled job
    -- For now, it's a placeholder for the aggregation logic
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- ============================================================================
-- SEED DATA: Initial Analytics Configuration
-- ============================================================================

-- Insert initial analytics snapshots for existing groups
INSERT INTO analytics_snapshots (
    group_id, snapshot_date, total_members, active_members,
    total_savings, avg_savings_per_member, total_loans_issued,
    loan_repayment_rate, total_achievements_earned, group_health_score
)
SELECT 
    g.id,
    CURRENT_DATE,
    COUNT(DISTINCT gm.id),
    COUNT(DISTINCT gm.id),
    COALESCE(SUM(ms.amount), 0),
    COALESCE(AVG(ms.amount), 0),
    COALESCE(SUM(gl.amount), 0),
    COALESCE(100 * COUNT(CASE WHEN gl.status = 'REPAID' THEN 1 END) / NULLIF(COUNT(gl.id), 0), 0),
    COALESCE(COUNT(DISTINCT ma.id), 0),
    calculate_group_health_score(g.id)
FROM savings_groups g
LEFT JOIN group_members gm ON g.id = gm.group_id
LEFT JOIN member_savings ms ON gm.id = ms.member_id
LEFT JOIN group_loans gl ON g.id = gl.group_id
LEFT JOIN member_achievements ma ON gm.id = ma.member_id
GROUP BY g.id
ON CONFLICT (group_id, snapshot_date) DO NOTHING;

-- ============================================================================
-- MIGRATION COMPLETE
-- ============================================================================
-- Phase 4 Analytics tables created successfully
-- Ready for analytics API implementation

