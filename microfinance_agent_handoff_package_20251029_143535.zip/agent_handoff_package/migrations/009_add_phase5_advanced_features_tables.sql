-- ============================================================================
-- PHASE 5: ADVANCED FEATURES - DATABASE MIGRATION
-- ============================================================================
-- This migration adds tables for:
-- 1. Document Management (enhanced)
-- 2. Mobile Money Integration (enhanced)
-- 3. Advanced Reporting
-- ============================================================================

-- ============================================================================
-- 1. DOCUMENT MANAGEMENT TABLES
-- ============================================================================

-- Document Categories and Templates
CREATE TABLE IF NOT EXISTS document_templates (
    id SERIAL PRIMARY KEY,
    group_id INTEGER NOT NULL REFERENCES savings_groups(id) ON DELETE CASCADE,
    template_name VARCHAR(100) NOT NULL,
    template_type VARCHAR(50) NOT NULL, -- MEETING_MINUTES, ATTENDANCE, SAVINGS_RECORD, LOAN_AGREEMENT, CONSTITUTION
    template_content TEXT,
    is_active BOOLEAN DEFAULT TRUE,
    created_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    created_by INTEGER REFERENCES users(id),
    UNIQUE(group_id, template_name)
);

-- Document Versioning and History
CREATE TABLE IF NOT EXISTS document_versions (
    id SERIAL PRIMARY KEY,
    document_id INTEGER NOT NULL REFERENCES activity_documents(id) ON DELETE CASCADE,
    version_number INTEGER NOT NULL,
    file_path VARCHAR(500) NOT NULL,
    file_size INTEGER NOT NULL,
    change_description TEXT,
    created_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    created_by INTEGER REFERENCES users(id),
    UNIQUE(document_id, version_number)
);

-- Document Approvals and Signatures
CREATE TABLE IF NOT EXISTS document_approvals (
    id SERIAL PRIMARY KEY,
    document_id INTEGER NOT NULL REFERENCES activity_documents(id) ON DELETE CASCADE,
    approver_id INTEGER NOT NULL REFERENCES users(id),
    approval_status VARCHAR(20) NOT NULL DEFAULT 'PENDING', -- PENDING, APPROVED, REJECTED
    approval_date TIMESTAMP,
    signature_path VARCHAR(500),
    comments TEXT,
    created_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    UNIQUE(document_id, approver_id)
);

-- ============================================================================
-- 2. MOBILE MONEY INTEGRATION TABLES
-- ============================================================================

-- Mobile Money Providers Configuration
CREATE TABLE IF NOT EXISTS mobile_money_providers (
    id SERIAL PRIMARY KEY,
    group_id INTEGER NOT NULL REFERENCES savings_groups(id) ON DELETE CASCADE,
    provider_name VARCHAR(50) NOT NULL, -- MTN, AIRTEL, VODAFONE, EQUITY_BANK
    provider_code VARCHAR(20) NOT NULL,
    api_key VARCHAR(255),
    api_secret VARCHAR(255),
    merchant_id VARCHAR(100),
    is_active BOOLEAN DEFAULT TRUE,
    is_configured BOOLEAN DEFAULT FALSE,
    configuration_date TIMESTAMP,
    created_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    UNIQUE(group_id, provider_name)
);

-- Mobile Money Transactions
CREATE TABLE IF NOT EXISTS mobile_money_transactions (
    id SERIAL PRIMARY KEY,
    group_id INTEGER NOT NULL REFERENCES savings_groups(id) ON DELETE CASCADE,
    member_id INTEGER NOT NULL REFERENCES members(id) ON DELETE CASCADE,
    provider_id INTEGER NOT NULL REFERENCES mobile_money_providers(id),
    transaction_type VARCHAR(20) NOT NULL, -- DEPOSIT, WITHDRAWAL, TRANSFER, PAYMENT
    amount DECIMAL(12, 2) NOT NULL,
    phone_number VARCHAR(20) NOT NULL,
    transaction_reference VARCHAR(100) UNIQUE,
    status VARCHAR(20) NOT NULL DEFAULT 'PENDING', -- PENDING, SUCCESS, FAILED, CANCELLED
    error_message TEXT,
    metadata JSONB,
    created_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    completed_date TIMESTAMP
);

-- Mobile Money Reconciliation
CREATE TABLE IF NOT EXISTS mobile_money_reconciliation (
    id SERIAL PRIMARY KEY,
    group_id INTEGER NOT NULL REFERENCES savings_groups(id) ON DELETE CASCADE,
    reconciliation_date DATE NOT NULL,
    provider_id INTEGER NOT NULL REFERENCES mobile_money_providers(id),
    total_transactions INTEGER,
    total_amount DECIMAL(12, 2),
    discrepancies INTEGER,
    status VARCHAR(20) NOT NULL DEFAULT 'PENDING', -- PENDING, COMPLETED, FAILED
    reconciliation_notes TEXT,
    created_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    created_by INTEGER REFERENCES users(id),
    UNIQUE(group_id, reconciliation_date, provider_id)
);

-- ============================================================================
-- 3. ADVANCED REPORTING TABLES
-- ============================================================================

-- Report Schedules (for automated reports)
CREATE TABLE IF NOT EXISTS report_schedules (
    id SERIAL PRIMARY KEY,
    group_id INTEGER NOT NULL REFERENCES savings_groups(id) ON DELETE CASCADE,
    report_type VARCHAR(50) NOT NULL, -- FINANCIAL, LOAN, ACHIEVEMENT, COMPLIANCE, CUSTOM
    report_name VARCHAR(100) NOT NULL,
    schedule_frequency VARCHAR(20) NOT NULL, -- DAILY, WEEKLY, MONTHLY, QUARTERLY, YEARLY
    schedule_day_of_week INTEGER, -- 0-6 for weekly
    schedule_day_of_month INTEGER, -- 1-31 for monthly
    is_active BOOLEAN DEFAULT TRUE,
    recipients JSONB, -- Array of email addresses
    report_format VARCHAR(20) NOT NULL DEFAULT 'PDF', -- PDF, EXCEL, CSV, JSON
    created_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    created_by INTEGER REFERENCES users(id)
);

-- Report Execution History
CREATE TABLE IF NOT EXISTS report_executions (
    id SERIAL PRIMARY KEY,
    schedule_id INTEGER NOT NULL REFERENCES report_schedules(id) ON DELETE CASCADE,
    execution_date TIMESTAMP NOT NULL,
    status VARCHAR(20) NOT NULL DEFAULT 'PENDING', -- PENDING, COMPLETED, FAILED
    file_path VARCHAR(500),
    file_size INTEGER,
    error_message TEXT,
    execution_time_ms INTEGER,
    created_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Custom Report Definitions
CREATE TABLE IF NOT EXISTS custom_reports (
    id SERIAL PRIMARY KEY,
    group_id INTEGER NOT NULL REFERENCES savings_groups(id) ON DELETE CASCADE,
    report_name VARCHAR(100) NOT NULL,
    report_description TEXT,
    report_query TEXT NOT NULL,
    report_parameters JSONB,
    visualization_type VARCHAR(50), -- TABLE, CHART, DASHBOARD
    is_public BOOLEAN DEFAULT FALSE,
    created_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    created_by INTEGER REFERENCES users(id),
    UNIQUE(group_id, report_name)
);

-- ============================================================================
-- INDEXES FOR PERFORMANCE
-- ============================================================================

CREATE INDEX idx_document_templates_group ON document_templates(group_id);
CREATE INDEX idx_document_versions_document ON document_versions(document_id);
CREATE INDEX idx_document_approvals_document ON document_approvals(document_id);
CREATE INDEX idx_document_approvals_approver ON document_approvals(approver_id);
CREATE INDEX idx_mobile_money_providers_group ON mobile_money_providers(group_id);
CREATE INDEX idx_mobile_money_transactions_group ON mobile_money_transactions(group_id);
CREATE INDEX idx_mobile_money_transactions_member ON mobile_money_transactions(member_id);
CREATE INDEX idx_mobile_money_transactions_status ON mobile_money_transactions(status);
CREATE INDEX idx_mobile_money_reconciliation_group ON mobile_money_reconciliation(group_id);
CREATE INDEX idx_report_schedules_group ON report_schedules(group_id);
CREATE INDEX idx_report_executions_schedule ON report_executions(schedule_id);
CREATE INDEX idx_custom_reports_group ON custom_reports(group_id);

-- ============================================================================
-- SEED DATA
-- ============================================================================

-- Seed document templates
INSERT INTO document_templates (group_id, template_name, template_type, template_content, created_by)
SELECT id, 'Standard Meeting Minutes', 'MEETING_MINUTES', 
'Meeting Date: ___\nAttendees: ___\nAgenda Items:\n1. ___\n2. ___\nDecisions: ___\nAction Items: ___',
1
FROM savings_groups LIMIT 1;

INSERT INTO document_templates (group_id, template_name, template_type, template_content, created_by)
SELECT id, 'Attendance Sheet', 'ATTENDANCE', 
'Date: ___\nMeeting: ___\nMember Name | Present | Signature\n___ | ___ | ___',
1
FROM savings_groups LIMIT 1;

-- Seed mobile money providers
INSERT INTO mobile_money_providers (group_id, provider_name, provider_code, is_active, created_by)
SELECT id, 'MTN Mobile Money', 'MTN', TRUE, 1
FROM savings_groups LIMIT 1;

INSERT INTO mobile_money_providers (group_id, provider_name, provider_code, is_active, created_by)
SELECT id, 'Airtel Money', 'AIRTEL', TRUE, 1
FROM savings_groups LIMIT 1;

-- ============================================================================
-- MIGRATION COMPLETE
-- ============================================================================

