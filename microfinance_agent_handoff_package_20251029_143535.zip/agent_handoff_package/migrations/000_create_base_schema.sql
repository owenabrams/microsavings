-- ============================================================================
-- BASE SCHEMA - CORE TABLES
-- Migration: 000_create_base_schema.sql
-- Description: Creates all base tables that other migrations depend on
-- Date: 2025-10-26
-- ============================================================================

BEGIN;

-- ============================================================================
-- 1. USERS TABLE (Core authentication)
-- ============================================================================
CREATE TABLE IF NOT EXISTS users (
    id SERIAL PRIMARY KEY,
    username VARCHAR(128) UNIQUE NOT NULL,
    email VARCHAR(128) UNIQUE NOT NULL,
    password VARCHAR(255) NOT NULL,
    active BOOLEAN DEFAULT TRUE NOT NULL,
    admin BOOLEAN DEFAULT FALSE NOT NULL,
    role VARCHAR(50) DEFAULT 'user' NOT NULL,
    is_super_admin BOOLEAN DEFAULT FALSE NOT NULL,
    created_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP NOT NULL
);

-- ============================================================================
-- 2. SAVINGS_GROUPS TABLE (Core group management)
-- ============================================================================
CREATE TABLE IF NOT EXISTS savings_groups (
    id SERIAL PRIMARY KEY,
    name VARCHAR(255) NOT NULL,
    description TEXT,
    group_code VARCHAR(50) UNIQUE NOT NULL,

    -- Enhanced location information (matches ORM model)
    country VARCHAR(100),
    region VARCHAR(100),
    district VARCHAR(100) NOT NULL,
    parish VARCHAR(100) NOT NULL,
    village VARCHAR(100) NOT NULL,

    -- Group governance and compliance
    constitution_document_url VARCHAR(255),
    registration_certificate_url VARCHAR(255),
    is_registered BOOLEAN DEFAULT FALSE,
    registration_number VARCHAR(100),
    registration_date DATE,

    -- Group lifecycle
    formation_date DATE,
    state VARCHAR(50) DEFAULT 'ACTIVE',

    -- Financial information
    savings_balance NUMERIC(12,2) DEFAULT 0.00,
    loan_balance NUMERIC(12,2) DEFAULT 0.00,
    loan_fund_balance NUMERIC(12,2) DEFAULT 0.00,
    target_amount NUMERIC(12,2),

    -- Member management
    members_count INTEGER DEFAULT 0,
    max_members INTEGER DEFAULT 30,

    -- Officer assignments
    chair_member_id INTEGER,
    treasurer_member_id INTEGER,
    secretary_member_id INTEGER,

    -- Group settings
    meeting_frequency VARCHAR(50) DEFAULT 'WEEKLY',
    minimum_contribution NUMERIC(10,2),

    -- Audit fields
    created_by INTEGER NOT NULL REFERENCES users(id),
    created_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP NOT NULL,

    -- Legacy fields (kept for backward compatibility)
    status VARCHAR(50) DEFAULT 'ACTIVE',
    constitution_file_path VARCHAR(255),
    cycle_start_date DATE,
    cycle_end_date DATE,
    cycle_status VARCHAR(50) DEFAULT 'ACTIVE'
);

-- ============================================================================
-- 3. GROUP_MEMBERS TABLE (Core member management)
-- ============================================================================
CREATE TABLE IF NOT EXISTS group_members (
    id SERIAL PRIMARY KEY,
    group_id INTEGER NOT NULL REFERENCES savings_groups(id) ON DELETE CASCADE,
    user_id INTEGER NOT NULL REFERENCES users(id),

    -- Member information (matches ORM model)
    first_name VARCHAR(100) NOT NULL,
    last_name VARCHAR(100) NOT NULL,
    email VARCHAR(128),
    phone_number VARCHAR(20),
    id_number VARCHAR(50),
    date_of_birth DATE,
    gender VARCHAR(10) NOT NULL,
    occupation VARCHAR(100),

    -- Membership details
    status VARCHAR(50) DEFAULT 'ACTIVE' NOT NULL,
    joined_date DATE DEFAULT CURRENT_DATE NOT NULL,
    is_active BOOLEAN DEFAULT TRUE,
    role VARCHAR(50) DEFAULT 'MEMBER',

    -- Financial tracking
    share_balance NUMERIC(12,2) DEFAULT 0.00,
    total_contributions NUMERIC(12,2) DEFAULT 0.00,

    -- Performance metrics
    attendance_percentage NUMERIC(5,2) DEFAULT 0.00,
    is_eligible_for_loans BOOLEAN DEFAULT FALSE,

    -- Audit fields
    created_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP NOT NULL
);

-- ============================================================================
-- 4. MEETINGS TABLE (Core meeting management)
-- ============================================================================
CREATE TABLE IF NOT EXISTS meetings (
    id SERIAL PRIMARY KEY,
    group_id INTEGER NOT NULL REFERENCES savings_groups(id) ON DELETE CASCADE,
    meeting_date DATE NOT NULL,
    meeting_time TIME,
    location VARCHAR(255),
    status VARCHAR(50) DEFAULT 'SCHEDULED' NOT NULL,
    meeting_type VARCHAR(50) DEFAULT 'REGULAR' NOT NULL,
    recorded_by INTEGER REFERENCES users(id),
    created_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP NOT NULL,
    scheduled_by INTEGER REFERENCES users(id),
    invitation_sent BOOLEAN DEFAULT FALSE,
    meeting_template_id INTEGER,
    is_recurring_instance BOOLEAN DEFAULT FALSE,
    recurrence_id VARCHAR(100),
    auto_generated BOOLEAN DEFAULT FALSE,
    meeting_link VARCHAR(255),
    meeting_password VARCHAR(100),
    max_participants INTEGER
);

-- ============================================================================
-- 5. SAVING_TYPES TABLE (Saving type definitions)
-- ============================================================================
CREATE TABLE IF NOT EXISTS saving_types (
    id SERIAL PRIMARY KEY,
    code VARCHAR(50) UNIQUE NOT NULL,
    name VARCHAR(100) NOT NULL,
    description TEXT,
    minimum_amount DECIMAL(15,2) DEFAULT 0.00,
    maximum_amount DECIMAL(15,2),
    is_mandatory BOOLEAN DEFAULT FALSE,
    created_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP NOT NULL
);

-- ============================================================================
-- 6. MEMBER_SAVINGS TABLE (Individual member savings)
-- ============================================================================
CREATE TABLE IF NOT EXISTS member_savings (
    id SERIAL PRIMARY KEY,
    member_id INTEGER NOT NULL REFERENCES group_members(id) ON DELETE CASCADE,
    saving_type_id INTEGER NOT NULL REFERENCES saving_types(id),
    amount DECIMAL(15,2) NOT NULL,
    meeting_id INTEGER REFERENCES meetings(id),
    transaction_date DATE DEFAULT CURRENT_DATE NOT NULL,
    created_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP NOT NULL
);

-- ============================================================================
-- 7. GROUP_TRANSACTIONS TABLE (Group-level transactions)
-- ============================================================================
CREATE TABLE IF NOT EXISTS group_transactions (
    id SERIAL PRIMARY KEY,
    group_id INTEGER NOT NULL REFERENCES savings_groups(id) ON DELETE CASCADE,
    member_id INTEGER REFERENCES group_members(id),
    transaction_type VARCHAR(50) NOT NULL,
    amount DECIMAL(15,2) NOT NULL,
    transaction_date DATE DEFAULT CURRENT_DATE NOT NULL,
    description TEXT,
    created_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP NOT NULL
);

-- ============================================================================
-- 8. GROUP_CASHBOOK TABLE (Financial records)
-- ============================================================================
CREATE TABLE IF NOT EXISTS group_cashbook (
    id SERIAL PRIMARY KEY,
    group_id INTEGER NOT NULL REFERENCES savings_groups(id) ON DELETE CASCADE,
    member_id INTEGER REFERENCES group_members(id),
    transaction_date DATE NOT NULL,
    reference_number VARCHAR(100),
    description VARCHAR(255) NOT NULL,
    entry_type VARCHAR(50) NOT NULL,
    amount DECIMAL(15,2) NOT NULL,
    total_balance DECIMAL(15,2) DEFAULT 0.00 NOT NULL,
    created_by INTEGER NOT NULL REFERENCES users(id),
    status VARCHAR(50) DEFAULT 'ACTIVE' NOT NULL,
    created_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP NOT NULL
);

-- ============================================================================
-- 9. MEETING_ATTENDANCE TABLE (Attendance tracking)
-- ============================================================================
CREATE TABLE IF NOT EXISTS meeting_attendance (
    id SERIAL PRIMARY KEY,
    group_id INTEGER NOT NULL REFERENCES savings_groups(id) ON DELETE CASCADE,
    member_id INTEGER NOT NULL REFERENCES group_members(id) ON DELETE CASCADE,
    meeting_date DATE NOT NULL,
    meeting_type VARCHAR(50) DEFAULT 'REGULAR' NOT NULL,
    attended BOOLEAN DEFAULT FALSE NOT NULL,
    recorded_by INTEGER NOT NULL REFERENCES users(id),
    created_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP NOT NULL,
    UNIQUE(group_id, member_id, meeting_date)
);

-- ============================================================================
-- 10. MEMBER_FINES TABLE (Fine management)
-- ============================================================================
CREATE TABLE IF NOT EXISTS member_fines (
    id SERIAL PRIMARY KEY,
    member_id INTEGER NOT NULL REFERENCES group_members(id) ON DELETE CASCADE,
    fine_type VARCHAR(50) NOT NULL,
    amount DECIMAL(15,2) NOT NULL,
    due_date DATE,
    paid_date DATE,
    paid BOOLEAN DEFAULT FALSE,
    created_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP NOT NULL
);

-- ============================================================================
-- 11. LOAN_ASSESSMENTS TABLE (Loan eligibility)
-- ============================================================================
CREATE TABLE IF NOT EXISTS loan_assessments (
    id SERIAL PRIMARY KEY,
    member_id INTEGER NOT NULL REFERENCES group_members(id) ON DELETE CASCADE,
    assessment_date DATE DEFAULT CURRENT_DATE NOT NULL,
    savings_history_score DECIMAL(5,2),
    attendance_score DECIMAL(5,2),
    payment_consistency_score DECIMAL(5,2),
    overall_score DECIMAL(5,2),
    risk_level VARCHAR(50),
    max_loan_amount DECIMAL(15,2),
    recommended_term_months INTEGER,
    valid_until DATE,
    created_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP NOT NULL
);

-- ============================================================================
-- 12. GROUP_LOANS TABLE (Group loan management)
-- ============================================================================
CREATE TABLE IF NOT EXISTS group_loans (
    id SERIAL PRIMARY KEY,
    group_id INTEGER NOT NULL REFERENCES savings_groups(id) ON DELETE CASCADE,
    member_id INTEGER NOT NULL REFERENCES group_members(id) ON DELETE CASCADE,
    loan_amount DECIMAL(15,2) NOT NULL,
    interest_rate DECIMAL(5,2),
    loan_term_months INTEGER,
    disbursement_date DATE,
    status VARCHAR(50) DEFAULT 'PENDING' NOT NULL,
    created_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP NOT NULL
);

-- ============================================================================
-- 13. LOAN_REPAYMENT_SCHEDULE TABLE (Repayment tracking)
-- ============================================================================
CREATE TABLE IF NOT EXISTS loan_repayment_schedule (
    id SERIAL PRIMARY KEY,
    loan_id INTEGER NOT NULL REFERENCES group_loans(id) ON DELETE CASCADE,
    due_date DATE NOT NULL,
    amount_due DECIMAL(15,2) NOT NULL,
    amount_paid DECIMAL(15,2) DEFAULT 0.00,
    paid_date DATE,
    status VARCHAR(50) DEFAULT 'PENDING' NOT NULL,
    created_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP NOT NULL
);

-- ============================================================================
-- 14. TARGET_SAVINGS_CAMPAIGNS TABLE (Campaign management)
-- ============================================================================
CREATE TABLE IF NOT EXISTS target_savings_campaigns (
    id SERIAL PRIMARY KEY,
    name VARCHAR(255) NOT NULL,
    description TEXT,
    target_amount DECIMAL(15,2) NOT NULL,
    start_date DATE NOT NULL,
    end_date DATE NOT NULL,
    created_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP NOT NULL
);

-- ============================================================================
-- 15. GROUP_TARGET_CAMPAIGNS TABLE (Group campaign participation)
-- ============================================================================
CREATE TABLE IF NOT EXISTS group_target_campaigns (
    id SERIAL PRIMARY KEY,
    campaign_id INTEGER NOT NULL REFERENCES target_savings_campaigns(id) ON DELETE CASCADE,
    group_id INTEGER NOT NULL REFERENCES savings_groups(id) ON DELETE CASCADE,
    assigned_by INTEGER NOT NULL REFERENCES users(id),
    status VARCHAR(50) DEFAULT 'ACTIVE' NOT NULL,
    total_saved DECIMAL(15,2) DEFAULT 0.00,
    completion_percentage DECIMAL(5,2) DEFAULT 0.00,
    created_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP NOT NULL,
    UNIQUE(campaign_id, group_id)
);

-- ============================================================================
-- 16. MEMBER_CAMPAIGN_PARTICIPATION TABLE (Member campaign participation)
-- ============================================================================
CREATE TABLE IF NOT EXISTS member_campaign_participations (
    id SERIAL PRIMARY KEY,
    member_id INTEGER NOT NULL REFERENCES group_members(id) ON DELETE CASCADE,
    campaign_id INTEGER NOT NULL REFERENCES target_savings_campaigns(id) ON DELETE CASCADE,
    amount_saved DECIMAL(15,2) DEFAULT 0.00,
    created_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP NOT NULL
);

-- ============================================================================
-- 17. CALENDAR_EVENTS TABLE (Calendar management)
-- ============================================================================
CREATE TABLE IF NOT EXISTS calendar_events (
    id SERIAL PRIMARY KEY,
    group_id INTEGER REFERENCES savings_groups(id) ON DELETE CASCADE,
    event_type VARCHAR(50) NOT NULL,
    event_date DATE NOT NULL,
    event_time TIME,
    title VARCHAR(255) NOT NULL,
    description TEXT,
    location VARCHAR(255),
    created_by INTEGER NOT NULL REFERENCES users(id),
    user_id INTEGER REFERENCES users(id),
    amount NUMERIC(15, 2),
    fund_type VARCHAR(20),
    verification_status VARCHAR(20),
    member_gender VARCHAR(10),
    member_role VARCHAR(50),
    mobile_money_provider VARCHAR(50),
    reference_id VARCHAR(100),
    reference_type VARCHAR(50),
    related_transaction_id INTEGER,
    related_loan_id INTEGER,
    related_campaign_id INTEGER,
    related_fine_id INTEGER,
    meeting_type VARCHAR(20),
    attendees_count INTEGER,
    total_members INTEGER,
    created_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP NOT NULL
);

-- ============================================================================
-- 18. NOTIFICATIONS TABLE (Notification system)
-- ============================================================================
CREATE TABLE IF NOT EXISTS notifications (
    id SERIAL PRIMARY KEY,
    user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    title VARCHAR(255) NOT NULL,
    message TEXT NOT NULL,
    notification_type VARCHAR(50),
    read BOOLEAN DEFAULT FALSE,
    created_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP NOT NULL
);

-- ============================================================================
-- 19. SAVING_TRANSACTIONS TABLE (Transaction history)
-- ============================================================================
CREATE TABLE IF NOT EXISTS saving_transactions (
    id SERIAL PRIMARY KEY,
    member_id INTEGER NOT NULL REFERENCES group_members(id) ON DELETE CASCADE,
    saving_type_id INTEGER NOT NULL REFERENCES saving_types(id),
    amount DECIMAL(15,2) NOT NULL,
    transaction_date DATE DEFAULT CURRENT_DATE NOT NULL,
    created_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP NOT NULL
);

-- ============================================================================
-- 20. CAMPAIGN_VOTES TABLE (Voting system)
-- ============================================================================
CREATE TABLE IF NOT EXISTS campaign_votes (
    id SERIAL PRIMARY KEY,
    campaign_id INTEGER NOT NULL REFERENCES target_savings_campaigns(id) ON DELETE CASCADE,
    member_id INTEGER NOT NULL REFERENCES group_members(id) ON DELETE CASCADE,
    vote_value BOOLEAN NOT NULL,
    created_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP NOT NULL
);

-- ============================================================================
-- 21. SERVICES TABLE (Microservices)
-- ============================================================================
CREATE TABLE IF NOT EXISTS services (
    id SERIAL PRIMARY KEY,
    name VARCHAR(128) UNIQUE NOT NULL,
    description TEXT,
    endpoint_url VARCHAR(255),
    active BOOLEAN DEFAULT TRUE NOT NULL,
    created_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP NOT NULL
);

-- ============================================================================
-- 22. SERVICE_ADMINS TABLE (Service admin mapping)
-- ============================================================================
CREATE TABLE IF NOT EXISTS service_admins (
    id SERIAL PRIMARY KEY,
    user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    service_id INTEGER NOT NULL REFERENCES services(id) ON DELETE CASCADE,
    granted_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP NOT NULL,
    granted_by INTEGER REFERENCES users(id),
    UNIQUE(user_id, service_id)
);

-- ============================================================================
-- 23. USER_SERVICE_PERMISSIONS TABLE (User permissions)
-- ============================================================================
CREATE TABLE IF NOT EXISTS user_service_permissions (
    id SERIAL PRIMARY KEY,
    user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    service_id INTEGER NOT NULL REFERENCES services(id) ON DELETE CASCADE,
    permissions VARCHAR(255) DEFAULT 'read',
    granted_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP NOT NULL,
    granted_by INTEGER REFERENCES users(id),
    UNIQUE(user_id, service_id)
);

-- ============================================================================
-- 24. SERVICE_ACCESS_REQUESTS TABLE (Access requests)
-- ============================================================================
CREATE TABLE IF NOT EXISTS service_access_requests (
    id SERIAL PRIMARY KEY,
    user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    service_id INTEGER NOT NULL REFERENCES services(id) ON DELETE CASCADE,
    requested_permissions VARCHAR(255) DEFAULT 'read',
    reason TEXT,
    status VARCHAR(50) DEFAULT 'pending',
    request_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP NOT NULL,
    reviewed_date TIMESTAMP,
    reviewed_by INTEGER REFERENCES users(id),
    review_notes TEXT
);

-- ============================================================================
-- 25. MOBILE_MONEY_ACCOUNT TABLE (Mobile money integration)
-- ============================================================================
CREATE TABLE IF NOT EXISTS mobile_money_account (
    id SERIAL PRIMARY KEY,
    member_id INTEGER NOT NULL REFERENCES group_members(id) ON DELETE CASCADE,
    provider VARCHAR(50) NOT NULL,
    account_number VARCHAR(50) NOT NULL,
    account_holder_name VARCHAR(100),
    is_active BOOLEAN DEFAULT TRUE,
    created_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP NOT NULL,
    UNIQUE(member_id, provider)
);

COMMIT;

