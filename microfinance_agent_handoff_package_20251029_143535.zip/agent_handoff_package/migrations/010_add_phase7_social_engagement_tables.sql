-- Phase 7: Social Engagement System
-- Migration: Add social engagement tables

-- Create social_posts table
CREATE TABLE IF NOT EXISTS social_posts (
    id SERIAL PRIMARY KEY,
    group_id INTEGER NOT NULL REFERENCES savings_groups(id) ON DELETE CASCADE,
    member_id INTEGER NOT NULL REFERENCES group_members(id) ON DELETE CASCADE,
    post_type VARCHAR(50) NOT NULL CHECK (post_type IN ('automatic', 'manual')),
    activity_type VARCHAR(100),
    activity_id INTEGER,
    title VARCHAR(255),
    content TEXT,
    privacy_level VARCHAR(50) NOT NULL DEFAULT 'pseudonym' CHECK (privacy_level IN ('real_name', 'pseudonym', 'anonymous', 'spoofed')),
    visibility VARCHAR(50) NOT NULL DEFAULT 'group_only' CHECK (visibility IN ('group_only', 'cross_group', 'public')),
    status VARCHAR(50) NOT NULL DEFAULT 'published' CHECK (status IN ('draft', 'pending', 'published', 'rejected')),
    attachment_ids JSONB DEFAULT '[]',
    created_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    published_date TIMESTAMP,
    created_by INTEGER REFERENCES users(id),
    updated_by INTEGER REFERENCES users(id)
);

CREATE INDEX idx_social_posts_group_id ON social_posts(group_id);
CREATE INDEX idx_social_posts_member_id ON social_posts(member_id);
CREATE INDEX idx_social_posts_status ON social_posts(status);
CREATE INDEX idx_social_posts_created_date ON social_posts(created_date DESC);

-- Create social_comments table
CREATE TABLE IF NOT EXISTS social_comments (
    id SERIAL PRIMARY KEY,
    post_id INTEGER NOT NULL REFERENCES social_posts(id) ON DELETE CASCADE,
    member_id INTEGER NOT NULL REFERENCES group_members(id) ON DELETE CASCADE,
    parent_comment_id INTEGER REFERENCES social_comments(id) ON DELETE CASCADE,
    content TEXT NOT NULL,
    privacy_level VARCHAR(50) NOT NULL DEFAULT 'pseudonym' CHECK (privacy_level IN ('real_name', 'pseudonym', 'anonymous', 'spoofed')),
    status VARCHAR(50) NOT NULL DEFAULT 'published' CHECK (status IN ('published', 'pending', 'rejected')),
    created_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    created_by INTEGER REFERENCES users(id),
    updated_by INTEGER REFERENCES users(id)
);

CREATE INDEX idx_social_comments_post_id ON social_comments(post_id);
CREATE INDEX idx_social_comments_member_id ON social_comments(member_id);
CREATE INDEX idx_social_comments_parent_id ON social_comments(parent_comment_id);
CREATE INDEX idx_social_comments_created_date ON social_comments(created_date DESC);

-- Create social_reactions table
CREATE TABLE IF NOT EXISTS social_reactions (
    id SERIAL PRIMARY KEY,
    post_id INTEGER REFERENCES social_posts(id) ON DELETE CASCADE,
    comment_id INTEGER REFERENCES social_comments(id) ON DELETE CASCADE,
    member_id INTEGER NOT NULL REFERENCES group_members(id) ON DELETE CASCADE,
    reaction_type VARCHAR(50) NOT NULL CHECK (reaction_type IN ('like', 'celebrate', 'inspire', 'motivate')),
    created_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    UNIQUE(post_id, comment_id, member_id, reaction_type)
);

CREATE INDEX idx_social_reactions_post_id ON social_reactions(post_id);
CREATE INDEX idx_social_reactions_comment_id ON social_reactions(comment_id);
CREATE INDEX idx_social_reactions_member_id ON social_reactions(member_id);

-- Create social_mentions table
CREATE TABLE IF NOT EXISTS social_mentions (
    id SERIAL PRIMARY KEY,
    post_id INTEGER REFERENCES social_posts(id) ON DELETE CASCADE,
    comment_id INTEGER REFERENCES social_comments(id) ON DELETE CASCADE,
    mentioned_member_id INTEGER NOT NULL REFERENCES group_members(id) ON DELETE CASCADE,
    created_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX idx_social_mentions_post_id ON social_mentions(post_id);
CREATE INDEX idx_social_mentions_comment_id ON social_mentions(comment_id);
CREATE INDEX idx_social_mentions_member_id ON social_mentions(mentioned_member_id);

-- Create social_hashtags table
CREATE TABLE IF NOT EXISTS social_hashtags (
    id SERIAL PRIMARY KEY,
    tag_name VARCHAR(100) NOT NULL UNIQUE,
    post_count INTEGER DEFAULT 0,
    created_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX idx_social_hashtags_tag_name ON social_hashtags(tag_name);

-- Create social_post_hashtags table
CREATE TABLE IF NOT EXISTS social_post_hashtags (
    id SERIAL PRIMARY KEY,
    post_id INTEGER NOT NULL REFERENCES social_posts(id) ON DELETE CASCADE,
    hashtag_id INTEGER NOT NULL REFERENCES social_hashtags(id) ON DELETE CASCADE,
    UNIQUE(post_id, hashtag_id)
);

CREATE INDEX idx_social_post_hashtags_post_id ON social_post_hashtags(post_id);
CREATE INDEX idx_social_post_hashtags_hashtag_id ON social_post_hashtags(hashtag_id);

-- Create social_attachments table
CREATE TABLE IF NOT EXISTS social_attachments (
    id SERIAL PRIMARY KEY,
    post_id INTEGER REFERENCES social_posts(id) ON DELETE CASCADE,
    comment_id INTEGER REFERENCES social_comments(id) ON DELETE CASCADE,
    file_name VARCHAR(255) NOT NULL,
    file_type VARCHAR(50) NOT NULL CHECK (file_type IN ('image', 'audio', 'video', 'document')),
    file_url TEXT NOT NULL,
    file_size INTEGER,
    created_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX idx_social_attachments_post_id ON social_attachments(post_id);
CREATE INDEX idx_social_attachments_comment_id ON social_attachments(comment_id);

-- Create social_admin_settings table
CREATE TABLE IF NOT EXISTS social_admin_settings (
    id SERIAL PRIMARY KEY,
    group_id INTEGER NOT NULL UNIQUE REFERENCES savings_groups(id) ON DELETE CASCADE,
    auto_post_savings BOOLEAN DEFAULT TRUE,
    auto_post_loans BOOLEAN DEFAULT TRUE,
    auto_post_achievements BOOLEAN DEFAULT TRUE,
    auto_post_meetings BOOLEAN DEFAULT TRUE,
    auto_post_iga BOOLEAN DEFAULT TRUE,
    default_privacy_level VARCHAR(50) DEFAULT 'pseudonym',
    require_post_approval BOOLEAN DEFAULT FALSE,
    allow_cross_group_posts BOOLEAN DEFAULT TRUE,
    allow_public_posts BOOLEAN DEFAULT FALSE,
    moderation_enabled BOOLEAN DEFAULT TRUE,
    created_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_by INTEGER REFERENCES users(id)
);

CREATE INDEX idx_social_admin_settings_group_id ON social_admin_settings(group_id);

-- Create social_member_settings table
CREATE TABLE IF NOT EXISTS social_member_settings (
    id SERIAL PRIMARY KEY,
    member_id INTEGER NOT NULL UNIQUE REFERENCES group_members(id) ON DELETE CASCADE,
    privacy_level VARCHAR(50) DEFAULT 'pseudonym',
    allow_mentions BOOLEAN DEFAULT TRUE,
    allow_comments BOOLEAN DEFAULT TRUE,
    allow_reactions BOOLEAN DEFAULT TRUE,
    created_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX idx_social_member_settings_member_id ON social_member_settings(member_id);

-- Create social_moderation_logs table
CREATE TABLE IF NOT EXISTS social_moderation_logs (
    id SERIAL PRIMARY KEY,
    admin_id INTEGER NOT NULL REFERENCES users(id),
    action_type VARCHAR(50) NOT NULL CHECK (action_type IN ('delete', 'approve', 'reject', 'block', 'unblock')),
    target_type VARCHAR(50) NOT NULL CHECK (target_type IN ('post', 'comment', 'member')),
    target_id INTEGER NOT NULL,
    reason TEXT,
    created_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX idx_social_moderation_logs_admin_id ON social_moderation_logs(admin_id);
CREATE INDEX idx_social_moderation_logs_created_date ON social_moderation_logs(created_date DESC);

-- Create social_blocked_members table
CREATE TABLE IF NOT EXISTS social_blocked_members (
    id SERIAL PRIMARY KEY,
    blocker_member_id INTEGER NOT NULL REFERENCES group_members(id) ON DELETE CASCADE,
    blocked_member_id INTEGER NOT NULL REFERENCES group_members(id) ON DELETE CASCADE,
    reason TEXT,
    created_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    UNIQUE(blocker_member_id, blocked_member_id)
);

CREATE INDEX idx_social_blocked_members_blocker ON social_blocked_members(blocker_member_id);
CREATE INDEX idx_social_blocked_members_blocked ON social_blocked_members(blocked_member_id);

-- Create social_post_views table (for analytics)
CREATE TABLE IF NOT EXISTS social_post_views (
    id SERIAL PRIMARY KEY,
    post_id INTEGER NOT NULL REFERENCES social_posts(id) ON DELETE CASCADE,
    member_id INTEGER NOT NULL REFERENCES group_members(id) ON DELETE CASCADE,
    viewed_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    UNIQUE(post_id, member_id)
);

CREATE INDEX idx_social_post_views_post_id ON social_post_views(post_id);
CREATE INDEX idx_social_post_views_member_id ON social_post_views(member_id);

-- Add triggers for updated_date
CREATE OR REPLACE FUNCTION update_social_posts_timestamp()
RETURNS TRIGGER AS $$
BEGIN
    NEW.updated_date = CURRENT_TIMESTAMP;
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER social_posts_update_timestamp
BEFORE UPDATE ON social_posts
FOR EACH ROW
EXECUTE FUNCTION update_social_posts_timestamp();

CREATE OR REPLACE FUNCTION update_social_comments_timestamp()
RETURNS TRIGGER AS $$
BEGIN
    NEW.updated_date = CURRENT_TIMESTAMP;
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER social_comments_update_timestamp
BEFORE UPDATE ON social_comments
FOR EACH ROW
EXECUTE FUNCTION update_social_comments_timestamp();

CREATE OR REPLACE FUNCTION update_social_admin_settings_timestamp()
RETURNS TRIGGER AS $$
BEGIN
    NEW.updated_date = CURRENT_TIMESTAMP;
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER social_admin_settings_update_timestamp
BEFORE UPDATE ON social_admin_settings
FOR EACH ROW
EXECUTE FUNCTION update_social_admin_settings_timestamp();

CREATE OR REPLACE FUNCTION update_social_member_settings_timestamp()
RETURNS TRIGGER AS $$
BEGIN
    NEW.updated_date = CURRENT_TIMESTAMP;
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER social_member_settings_update_timestamp
BEFORE UPDATE ON social_member_settings
FOR EACH ROW
EXECUTE FUNCTION update_social_member_settings_timestamp();

