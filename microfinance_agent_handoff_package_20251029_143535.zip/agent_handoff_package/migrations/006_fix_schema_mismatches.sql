-- Migration 006: Fix Schema Mismatches Between Database and ORM Models
-- Date: 2025-10-27
-- Purpose: Align database schema with ORM model expectations
-- Impact: Fixes critical API failures, enables E2E tests to run

-- ============================================================================
-- PRIORITY 0: CRITICAL - Fix savings_groups table (group_code generation)
-- ============================================================================

BEGIN;

-- Temporarily drop UNIQUE constraint to allow populating existing groups
ALTER TABLE savings_groups DROP CONSTRAINT IF EXISTS savings_groups_group_code_key;

-- Populate group_code for existing groups that have NULL
-- Format: SG-YYYYMMDD-XXXX (e.g., SG-20251027-0001)
WITH numbered_groups AS (
  SELECT id, ROW_NUMBER() OVER (ORDER BY id) as row_num
  FROM savings_groups
  WHERE group_code IS NULL OR group_code = ''
)
UPDATE savings_groups g
SET group_code = 'SG-' || TO_CHAR(CURRENT_DATE, 'YYYYMMDD') || '-' || LPAD(ng.row_num::TEXT, 4, '0')
FROM numbered_groups ng
WHERE g.id = ng.id;

-- Make group_code NOT NULL
ALTER TABLE savings_groups ALTER COLUMN group_code SET NOT NULL;

-- Restore UNIQUE constraint on group_code
ALTER TABLE savings_groups ADD CONSTRAINT savings_groups_group_code_key UNIQUE (group_code);

COMMIT;

-- ============================================================================
-- PRIORITY 1: CRITICAL - Fix group_loans table (API currently failing)
-- ============================================================================

BEGIN;

-- 1. Rename columns to match ORM model
ALTER TABLE group_loans RENAME COLUMN loan_amount TO principal;
ALTER TABLE group_loans RENAME COLUMN loan_term_months TO term_months;
ALTER TABLE group_loans RENAME COLUMN interest_rate TO interest_rate_annual;

-- 2. Add missing columns
ALTER TABLE group_loans ADD COLUMN IF NOT EXISTS purpose TEXT;
ALTER TABLE group_loans ADD COLUMN IF NOT EXISTS request_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP;
ALTER TABLE group_loans ADD COLUMN IF NOT EXISTS approval_date TIMESTAMP;
ALTER TABLE group_loans ADD COLUMN IF NOT EXISTS due_date DATE;
ALTER TABLE group_loans ADD COLUMN IF NOT EXISTS outstanding_balance NUMERIC(12,2) DEFAULT 0.00;
ALTER TABLE group_loans ADD COLUMN IF NOT EXISTS total_repaid NUMERIC(12,2) DEFAULT 0.00;
ALTER TABLE group_loans ADD COLUMN IF NOT EXISTS requested_by INTEGER;
ALTER TABLE group_loans ADD COLUMN IF NOT EXISTS approved_by INTEGER;
ALTER TABLE group_loans ADD COLUMN IF NOT EXISTS officer_approvals TEXT;
ALTER TABLE group_loans ADD COLUMN IF NOT EXISTS updated_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP;

-- 3. Rename disbursement_date to disbursal_date and change type
ALTER TABLE group_loans RENAME COLUMN disbursement_date TO disbursal_date;
ALTER TABLE group_loans ALTER COLUMN disbursal_date TYPE TIMESTAMP USING disbursal_date::TIMESTAMP;

-- 4. Add foreign key constraints for new columns
ALTER TABLE group_loans 
  ADD CONSTRAINT group_loans_requested_by_fkey 
  FOREIGN KEY (requested_by) REFERENCES group_members(id) ON DELETE CASCADE;

ALTER TABLE group_loans 
  ADD CONSTRAINT group_loans_approved_by_fkey 
  FOREIGN KEY (approved_by) REFERENCES users(id) ON DELETE SET NULL;

-- 5. Migrate data for new columns
-- Set requested_by to member_id for existing loans
UPDATE group_loans SET requested_by = member_id WHERE requested_by IS NULL;

-- Set request_date to created_date for existing loans
UPDATE group_loans SET request_date = created_date WHERE request_date IS NULL;

-- Calculate outstanding_balance (principal - total_repaid)
UPDATE group_loans SET outstanding_balance = principal WHERE outstanding_balance IS NULL OR outstanding_balance = 0;

COMMIT;

-- ============================================================================
-- PRIORITY 2: HIGH - Fix group_members table
-- ============================================================================

BEGIN;

-- The ORM uses first_name, last_name, phone_number, status (not name, phone, is_active)
-- Database already has these columns, so no changes needed
-- Just ensure first_name and last_name are NOT NULL (they should be)

-- Verify constraints are correct
-- first_name and last_name should be NOT NULL
-- phone_number can be NULL
-- status should have default 'ACTIVE'

COMMIT;

-- ============================================================================
-- PRIORITY 3: MEDIUM - Fix meetings table
-- ============================================================================

BEGIN;

-- 1. Add missing columns that ORM expects
ALTER TABLE meetings ADD COLUMN IF NOT EXISTS meeting_number INTEGER;
ALTER TABLE meetings ADD COLUMN IF NOT EXISTS start_time TIMESTAMP;
ALTER TABLE meetings ADD COLUMN IF NOT EXISTS end_time TIMESTAMP;
ALTER TABLE meetings ADD COLUMN IF NOT EXISTS total_members INTEGER DEFAULT 0;
ALTER TABLE meetings ADD COLUMN IF NOT EXISTS members_present INTEGER DEFAULT 0;
ALTER TABLE meetings ADD COLUMN IF NOT EXISTS quorum_met BOOLEAN DEFAULT FALSE;
ALTER TABLE meetings ADD COLUMN IF NOT EXISTS total_savings_collected NUMERIC(12,2) DEFAULT 0.00;
ALTER TABLE meetings ADD COLUMN IF NOT EXISTS loans_disbursed_count INTEGER DEFAULT 0;

-- 2. Populate meeting_number for existing meetings
-- Assign sequential numbers per group based on meeting_date
WITH numbered_meetings AS (
  SELECT id, ROW_NUMBER() OVER (PARTITION BY group_id ORDER BY meeting_date, created_date) as num
  FROM meetings
  WHERE meeting_number IS NULL
)
UPDATE meetings m
SET meeting_number = nm.num
FROM numbered_meetings nm
WHERE m.id = nm.id;

-- 3. Make meeting_number NOT NULL after populating
ALTER TABLE meetings ALTER COLUMN meeting_number SET NOT NULL;

-- 4. Add unique constraint for meeting_number per group
ALTER TABLE meetings 
  ADD CONSTRAINT unique_group_meeting_number 
  UNIQUE (group_id, meeting_number);

-- 5. Populate start_time from meeting_date and meeting_time if available
UPDATE meetings 
SET start_time = (meeting_date + meeting_time)::TIMESTAMP
WHERE start_time IS NULL AND meeting_time IS NOT NULL;

-- If meeting_time is NULL, just use meeting_date at midnight
UPDATE meetings 
SET start_time = meeting_date::TIMESTAMP
WHERE start_time IS NULL;

COMMIT;

-- ============================================================================
-- VERIFICATION QUERIES
-- ============================================================================

-- Verify group_loans columns
SELECT column_name, data_type, is_nullable
FROM information_schema.columns
WHERE table_name = 'group_loans'
  AND column_name IN ('principal', 'term_months', 'interest_rate_annual', 'disbursal_date', 
                      'purpose', 'request_date', 'outstanding_balance', 'requested_by')
ORDER BY column_name;

-- Verify group_members columns
SELECT column_name, data_type, is_nullable
FROM information_schema.columns
WHERE table_name = 'group_members'
  AND column_name IN ('name', 'phone', 'first_name', 'last_name', 'phone_number')
ORDER BY column_name;

-- Verify meetings columns
SELECT column_name, data_type, is_nullable
FROM information_schema.columns
WHERE table_name = 'meetings'
  AND column_name IN ('meeting_number', 'start_time', 'end_time', 'total_members', 
                      'members_present', 'quorum_met')
ORDER BY column_name;

-- ============================================================================
-- ROLLBACK SCRIPT (In case something goes wrong)
-- ============================================================================

-- ROLLBACK FOR group_loans:
-- ALTER TABLE group_loans RENAME COLUMN principal TO loan_amount;
-- ALTER TABLE group_loans RENAME COLUMN term_months TO loan_term_months;
-- ALTER TABLE group_loans RENAME COLUMN interest_rate_annual TO interest_rate;
-- ALTER TABLE group_loans RENAME COLUMN disbursal_date TO disbursement_date;
-- ALTER TABLE group_loans ALTER COLUMN disbursement_date TYPE DATE;
-- ALTER TABLE group_loans DROP COLUMN IF EXISTS purpose;
-- ALTER TABLE group_loans DROP COLUMN IF EXISTS request_date;
-- ALTER TABLE group_loans DROP COLUMN IF EXISTS approval_date;
-- ALTER TABLE group_loans DROP COLUMN IF EXISTS due_date;
-- ALTER TABLE group_loans DROP COLUMN IF EXISTS outstanding_balance;
-- ALTER TABLE group_loans DROP COLUMN IF EXISTS total_repaid;
-- ALTER TABLE group_loans DROP COLUMN IF EXISTS requested_by;
-- ALTER TABLE group_loans DROP COLUMN IF EXISTS approved_by;
-- ALTER TABLE group_loans DROP COLUMN IF EXISTS officer_approvals;
-- ALTER TABLE group_loans DROP COLUMN IF EXISTS updated_date;

-- ROLLBACK FOR group_members:
-- ALTER TABLE group_members DROP COLUMN IF EXISTS name;
-- ALTER TABLE group_members DROP COLUMN IF EXISTS phone;

-- ROLLBACK FOR meetings:
-- ALTER TABLE meetings DROP CONSTRAINT IF EXISTS unique_group_meeting_number;
-- ALTER TABLE meetings DROP COLUMN IF EXISTS meeting_number;
-- ALTER TABLE meetings DROP COLUMN IF EXISTS start_time;
-- ALTER TABLE meetings DROP COLUMN IF EXISTS end_time;
-- ALTER TABLE meetings DROP COLUMN IF EXISTS total_members;
-- ALTER TABLE meetings DROP COLUMN IF EXISTS members_present;
-- ALTER TABLE meetings DROP COLUMN IF EXISTS quorum_met;
-- ALTER TABLE meetings DROP COLUMN IF EXISTS total_savings_collected;
-- ALTER TABLE meetings DROP COLUMN IF EXISTS loans_disbursed_count;

-- ============================================================================
-- NOTES
-- ============================================================================

-- 1. This migration preserves all existing data
-- 2. Old columns (first_name, last_name, phone_number) are kept for backward compatibility
-- 3. Data is migrated from old columns to new columns
-- 4. Foreign key constraints are added for data integrity
-- 5. Unique constraints are added where needed
-- 6. All changes are wrapped in transactions for safety
-- 7. Verification queries are included to confirm changes
-- 8. Rollback script is provided in case of issues

-- After running this migration:
-- 1. Test API endpoints: curl http://localhost:5001/api/savings-groups
-- 2. Run E2E tests: pytest tests/test_e2e_current_state.py -v
-- 3. If everything works, consider dropping old columns in a future migration
-- 4. Reseed database if needed for comprehensive testing

