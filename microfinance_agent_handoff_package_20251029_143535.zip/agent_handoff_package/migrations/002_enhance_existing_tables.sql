-- ============================================================================
-- MEETING SCHEDULER SYSTEM - ENHANCE EXISTING TABLES
-- Migration: 002_enhance_existing_tables.sql
-- Description: Adds scheduling fields to existing meetings table
-- Date: 2025-10-02
-- ============================================================================

BEGIN;

-- ============================================================================
-- ENHANCE MEETINGS TABLE FOR SCHEDULING
-- ============================================================================

-- Add scheduling-related fields to meetings table
ALTER TABLE meetings ADD COLUMN IF NOT EXISTS scheduled_by INTEGER REFERENCES users(id);
ALTER TABLE meetings ADD COLUMN IF NOT EXISTS invitation_sent BOOLEAN DEFAULT FALSE;
ALTER TABLE meetings ADD COLUMN IF NOT EXISTS invitation_sent_date TIMESTAMP;
ALTER TABLE meetings ADD COLUMN IF NOT EXISTS meeting_template_id INTEGER REFERENCES meeting_templates(id);
ALTER TABLE meetings ADD COLUMN IF NOT EXISTS is_recurring_instance BOOLEAN DEFAULT FALSE;
ALTER TABLE meetings ADD COLUMN IF NOT EXISTS recurrence_id INTEGER;
ALTER TABLE meetings ADD COLUMN IF NOT EXISTS auto_generated BOOLEAN DEFAULT FALSE;
ALTER TABLE meetings ADD COLUMN IF NOT EXISTS meeting_link VARCHAR(500);
ALTER TABLE meetings ADD COLUMN IF NOT EXISTS meeting_password VARCHAR(100);
ALTER TABLE meetings ADD COLUMN IF NOT EXISTS max_participants INTEGER;
ALTER TABLE meetings ADD COLUMN IF NOT EXISTS registration_required BOOLEAN DEFAULT FALSE;
ALTER TABLE meetings ADD COLUMN IF NOT EXISTS registration_deadline TIMESTAMP;

-- Add comments for documentation
COMMENT ON COLUMN meetings.scheduled_by IS 'User who scheduled this meeting';
COMMENT ON COLUMN meetings.invitation_sent IS 'Whether invitations have been sent';
COMMENT ON COLUMN meetings.invitation_sent_date IS 'When invitations were sent';
COMMENT ON COLUMN meetings.meeting_template_id IS 'Template used to create this meeting';
COMMENT ON COLUMN meetings.is_recurring_instance IS 'Whether this is part of a recurring series';
COMMENT ON COLUMN meetings.recurrence_id IS 'Groups recurring meetings together';
COMMENT ON COLUMN meetings.auto_generated IS 'Whether meeting was auto-generated from template';
COMMENT ON COLUMN meetings.meeting_link IS 'Online meeting link (Zoom, Teams, etc.)';
COMMENT ON COLUMN meetings.meeting_password IS 'Password for online meeting';
COMMENT ON COLUMN meetings.max_participants IS 'Maximum number of participants allowed';
COMMENT ON COLUMN meetings.registration_required IS 'Whether participants must register';
COMMENT ON COLUMN meetings.registration_deadline IS 'Deadline for registration';

-- ============================================================================
-- ENHANCE MEETING_ATTENDANCE TABLE FOR ACTIVITY TRACKING
-- ============================================================================

-- Add activity participation fields (if not already exist)
ALTER TABLE meeting_attendance ADD COLUMN IF NOT EXISTS savings_contributed BOOLEAN DEFAULT FALSE;
ALTER TABLE meeting_attendance ADD COLUMN IF NOT EXISTS savings_amount DECIMAL(12,2) DEFAULT 0.00;
ALTER TABLE meeting_attendance ADD COLUMN IF NOT EXISTS loan_activity BOOLEAN DEFAULT FALSE;
ALTER TABLE meeting_attendance ADD COLUMN IF NOT EXISTS loan_amount DECIMAL(12,2) DEFAULT 0.00;
ALTER TABLE meeting_attendance ADD COLUMN IF NOT EXISTS fine_paid BOOLEAN DEFAULT FALSE;
ALTER TABLE meeting_attendance ADD COLUMN IF NOT EXISTS fine_amount DECIMAL(12,2) DEFAULT 0.00;
ALTER TABLE meeting_attendance ADD COLUMN IF NOT EXISTS activity_participation_score DECIMAL(5,2) DEFAULT 0.00;
ALTER TABLE meeting_attendance ADD COLUMN IF NOT EXISTS geographic_location VARCHAR(255);
ALTER TABLE meeting_attendance ADD COLUMN IF NOT EXISTS attendance_method VARCHAR(50) DEFAULT 'PHYSICAL';
ALTER TABLE meeting_attendance ADD COLUMN IF NOT EXISTS check_in_time TIMESTAMP;
ALTER TABLE meeting_attendance ADD COLUMN IF NOT EXISTS check_out_time TIMESTAMP;

-- Add constraints for new fields
ALTER TABLE meeting_attendance ADD CONSTRAINT IF NOT EXISTS check_savings_amount 
    CHECK (savings_amount >= 0);
ALTER TABLE meeting_attendance ADD CONSTRAINT IF NOT EXISTS check_loan_amount 
    CHECK (loan_amount >= 0);
ALTER TABLE meeting_attendance ADD CONSTRAINT IF NOT EXISTS check_fine_amount 
    CHECK (fine_amount >= 0);
ALTER TABLE meeting_attendance ADD CONSTRAINT IF NOT EXISTS check_activity_participation_score 
    CHECK (activity_participation_score >= 0 AND activity_participation_score <= 100);
ALTER TABLE meeting_attendance ADD CONSTRAINT IF NOT EXISTS check_attendance_method 
    CHECK (attendance_method IN ('PHYSICAL', 'ONLINE', 'HYBRID', 'PHONE'));

-- Add comments
COMMENT ON COLUMN meeting_attendance.savings_contributed IS 'Whether member contributed savings during meeting';
COMMENT ON COLUMN meeting_attendance.savings_amount IS 'Amount of savings contributed';
COMMENT ON COLUMN meeting_attendance.loan_activity IS 'Whether member had loan activity';
COMMENT ON COLUMN meeting_attendance.loan_amount IS 'Amount involved in loan activity';
COMMENT ON COLUMN meeting_attendance.fine_paid IS 'Whether member paid fines';
COMMENT ON COLUMN meeting_attendance.fine_amount IS 'Amount of fines paid';
COMMENT ON COLUMN meeting_attendance.activity_participation_score IS 'Overall participation score (0-100)';
COMMENT ON COLUMN meeting_attendance.geographic_location IS 'Location coordinates or address';
COMMENT ON COLUMN meeting_attendance.attendance_method IS 'How member attended (physical, online, etc.)';
COMMENT ON COLUMN meeting_attendance.check_in_time IS 'When member checked in';
COMMENT ON COLUMN meeting_attendance.check_out_time IS 'When member checked out';

-- ============================================================================
-- ENHANCE GROUP_MEMBERS TABLE FOR ATTENDANCE TRACKING
-- ============================================================================

-- Add attendance tracking fields (if not already exist)
ALTER TABLE group_members ADD COLUMN IF NOT EXISTS total_meetings_eligible INTEGER DEFAULT 0;
ALTER TABLE group_members ADD COLUMN IF NOT EXISTS total_meetings_attended INTEGER DEFAULT 0;
ALTER TABLE group_members ADD COLUMN IF NOT EXISTS attendance_percentage DECIMAL(5,2) DEFAULT 0.00;
ALTER TABLE group_members ADD COLUMN IF NOT EXISTS is_eligible_for_loans BOOLEAN DEFAULT FALSE;
ALTER TABLE group_members ADD COLUMN IF NOT EXISTS loan_eligibility_reason TEXT;
ALTER TABLE group_members ADD COLUMN IF NOT EXISTS last_attendance_update TIMESTAMP DEFAULT CURRENT_TIMESTAMP;

-- Add constraints
ALTER TABLE group_members ADD CONSTRAINT IF NOT EXISTS check_attendance_percentage 
    CHECK (attendance_percentage >= 0 AND attendance_percentage <= 100);
ALTER TABLE group_members ADD CONSTRAINT IF NOT EXISTS check_meeting_counts 
    CHECK (total_meetings_attended <= total_meetings_eligible);

-- Add comments
COMMENT ON COLUMN group_members.total_meetings_eligible IS 'Total meetings member was eligible to attend';
COMMENT ON COLUMN group_members.total_meetings_attended IS 'Total meetings member actually attended';
COMMENT ON COLUMN group_members.attendance_percentage IS 'Calculated attendance percentage';
COMMENT ON COLUMN group_members.is_eligible_for_loans IS 'Whether member meets attendance requirement for loans';
COMMENT ON COLUMN group_members.loan_eligibility_reason IS 'Reason for loan eligibility status';
COMMENT ON COLUMN group_members.last_attendance_update IS 'When attendance was last calculated';

-- ============================================================================
-- ENHANCE SAVINGS_GROUPS TABLE FOR GEOGRAPHIC AND CYCLE TRACKING
-- ============================================================================

-- Add geographic fields (if not already exist)
ALTER TABLE savings_groups ADD COLUMN IF NOT EXISTS region VARCHAR(100);
ALTER TABLE savings_groups ADD COLUMN IF NOT EXISTS district VARCHAR(100);
ALTER TABLE savings_groups ADD COLUMN IF NOT EXISTS parish VARCHAR(100);
ALTER TABLE savings_groups ADD COLUMN IF NOT EXISTS village VARCHAR(100);
ALTER TABLE savings_groups ADD COLUMN IF NOT EXISTS latitude DECIMAL(10,8);
ALTER TABLE savings_groups ADD COLUMN IF NOT EXISTS longitude DECIMAL(11,8);

-- Add cycle tracking fields (if not already exist)
ALTER TABLE savings_groups ADD COLUMN IF NOT EXISTS current_cycle_number INTEGER DEFAULT 1;
ALTER TABLE savings_groups ADD COLUMN IF NOT EXISTS cycle_duration_months INTEGER DEFAULT 12;
ALTER TABLE savings_groups ADD COLUMN IF NOT EXISTS current_cycle_start_date DATE;
ALTER TABLE savings_groups ADD COLUMN IF NOT EXISTS current_cycle_end_date DATE;
ALTER TABLE savings_groups ADD COLUMN IF NOT EXISTS next_shareout_date DATE;
ALTER TABLE savings_groups ADD COLUMN IF NOT EXISTS total_cycles_completed INTEGER DEFAULT 0;
ALTER TABLE savings_groups ADD COLUMN IF NOT EXISTS credit_score DECIMAL(5,2) DEFAULT 0.00;
ALTER TABLE savings_groups ADD COLUMN IF NOT EXISTS is_in_third_year BOOLEAN DEFAULT FALSE;
ALTER TABLE savings_groups ADD COLUMN IF NOT EXISTS passbook_status VARCHAR(20) DEFAULT 'CURRENT';
ALTER TABLE savings_groups ADD COLUMN IF NOT EXISTS ledger_status VARCHAR(20) DEFAULT 'CURRENT';

-- Add constraints
ALTER TABLE savings_groups ADD CONSTRAINT IF NOT EXISTS check_current_cycle_number 
    CHECK (current_cycle_number > 0);
ALTER TABLE savings_groups ADD CONSTRAINT IF NOT EXISTS check_cycle_duration_months 
    CHECK (cycle_duration_months > 0);
ALTER TABLE savings_groups ADD CONSTRAINT IF NOT EXISTS check_total_cycles_completed 
    CHECK (total_cycles_completed >= 0);
ALTER TABLE savings_groups ADD CONSTRAINT IF NOT EXISTS check_credit_score 
    CHECK (credit_score >= 0 AND credit_score <= 100);
ALTER TABLE savings_groups ADD CONSTRAINT IF NOT EXISTS check_latitude 
    CHECK (latitude BETWEEN -90 AND 90);
ALTER TABLE savings_groups ADD CONSTRAINT IF NOT EXISTS check_longitude 
    CHECK (longitude BETWEEN -180 AND 180);
ALTER TABLE savings_groups ADD CONSTRAINT IF NOT EXISTS check_passbook_status 
    CHECK (passbook_status IN ('CURRENT', 'OUTDATED', 'MISSING', 'UNDER_REVIEW'));
ALTER TABLE savings_groups ADD CONSTRAINT IF NOT EXISTS check_ledger_status 
    CHECK (ledger_status IN ('CURRENT', 'OUTDATED', 'MISSING', 'UNDER_REVIEW'));

-- Add comments
COMMENT ON COLUMN savings_groups.region IS 'Administrative region';
COMMENT ON COLUMN savings_groups.district IS 'Administrative district';
COMMENT ON COLUMN savings_groups.parish IS 'Administrative parish';
COMMENT ON COLUMN savings_groups.village IS 'Village or local area';
COMMENT ON COLUMN savings_groups.latitude IS 'Geographic latitude coordinate';
COMMENT ON COLUMN savings_groups.longitude IS 'Geographic longitude coordinate';
COMMENT ON COLUMN savings_groups.current_cycle_number IS 'Current savings cycle number';
COMMENT ON COLUMN savings_groups.cycle_duration_months IS 'Duration of each cycle in months';
COMMENT ON COLUMN savings_groups.current_cycle_start_date IS 'Start date of current cycle';
COMMENT ON COLUMN savings_groups.current_cycle_end_date IS 'End date of current cycle';
COMMENT ON COLUMN savings_groups.next_shareout_date IS 'Next scheduled share-out date';
COMMENT ON COLUMN savings_groups.total_cycles_completed IS 'Total number of completed cycles';
COMMENT ON COLUMN savings_groups.credit_score IS 'Group credit score (0-100)';
COMMENT ON COLUMN savings_groups.is_in_third_year IS 'Whether group is in third year or beyond';
COMMENT ON COLUMN savings_groups.passbook_status IS 'Status of group passbook';
COMMENT ON COLUMN savings_groups.ledger_status IS 'Status of group ledger';

COMMIT;
