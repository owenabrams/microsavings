-- Migration: Add activity_id to mobile_money_payments for linking to specific meeting activities
-- Date: 2025-10-27
-- Purpose: Enable members to submit mobile money payments for specific meeting activities

-- Add activity_id column to mobile_money_payments
ALTER TABLE mobile_money_payments 
ADD COLUMN IF NOT EXISTS activity_id INTEGER REFERENCES meeting_activities(id) ON DELETE SET NULL;

-- Add index for faster queries
CREATE INDEX IF NOT EXISTS idx_mobile_money_payments_activity 
ON mobile_money_payments(activity_id);

-- Add comment
COMMENT ON COLUMN mobile_money_payments.activity_id IS 'Link to specific meeting activity (e.g., PERSONAL_SAVINGS, LOAN_REPAYMENT)';

-- Update existing payments to link to activities if meeting_id exists
-- This is a best-effort migration - we'll try to match payment_type to activity_type
UPDATE mobile_money_payments mmp
SET activity_id = (
    SELECT ma.id 
    FROM meeting_activities ma
    WHERE ma.meeting_id = mmp.meeting_id
    AND (
        (mmp.payment_type = 'SAVINGS' AND ma.activity_type IN ('PERSONAL_SAVINGS', 'TARGET_SAVINGS'))
        OR (mmp.payment_type = 'LOAN_REPAYMENT' AND ma.activity_type = 'LOAN_REPAYMENT')
        OR (mmp.payment_type = 'FINE' AND ma.activity_type = 'FINE_COLLECTION')
        OR (mmp.payment_type = 'CONTRIBUTION' AND ma.activity_type IN ('ECD_FUND', 'SOCIAL_FUND'))
    )
    LIMIT 1
)
WHERE mmp.meeting_id IS NOT NULL 
AND mmp.activity_id IS NULL;

-- Add proof_document_url column for storing uploaded proof documents
ALTER TABLE mobile_money_payments 
ADD COLUMN IF NOT EXISTS proof_document_url VARCHAR(500);

-- Add comment
COMMENT ON COLUMN mobile_money_payments.proof_document_url IS 'URL to uploaded proof document (receipt screenshot, etc.)';

-- Add index for verification queries
CREATE INDEX IF NOT EXISTS idx_mobile_money_payments_verification 
ON mobile_money_payments(verification_status, group_id);

-- Migration complete
SELECT 'Migration 008 completed successfully' AS status;

